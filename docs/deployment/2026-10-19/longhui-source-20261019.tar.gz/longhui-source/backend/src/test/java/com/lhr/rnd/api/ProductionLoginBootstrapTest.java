package com.lhr.rnd.api;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@SpringBootTest(properties = {
    "spring.datasource.url=jdbc:h2:mem:production_login;MODE=PostgreSQL;DATABASE_TO_LOWER=FALSE;DB_CLOSE_DELAY=-1",
    "rnd.auth.bootstrap-users=false", "rnd.feedback.bootstrap-demo=false",
    "rnd.feishu.bootstrap-users=false", "rnd.feishu.enabled=false"
})
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ProductionLoginBootstrapTest {
    @Autowired MockMvc mvc;
    @Autowired JdbcTemplate jdbc;
    @Test void defaultPasswordMustNotLoginWhenBootstrapIsDisabled() throws Exception {
        long before = jdbc.queryForObject("select count(*) from user_account", Long.class);
        mvc.perform(post("/api/v1/auth/login").contentType(MediaType.APPLICATION_JSON)
            .content("{\"username\":\"rnd_assistant\",\"password\":\"123456\"}"))
            .andExpect(jsonPath("$.code").value("AUTH_CREDENTIAL_INVALID"));
        assertEquals(before, jdbc.queryForObject("select count(*) from user_account", Long.class));
    }
}
