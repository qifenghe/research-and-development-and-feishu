package com.lhr.rnd.api;

import com.lhr.rnd.model.ArchiveFileView;
import com.lhr.rnd.model.DashboardOverview;
import com.lhr.rnd.model.RndTask;
import com.lhr.rnd.model.RndTaskDetailView;
import com.lhr.rnd.model.ExperimentForm;
import com.lhr.rnd.model.ExperimentProcessStep;
import com.lhr.rnd.model.SampleVersionTimelineItem;
import com.lhr.rnd.model.PricingFileDetailView;
import com.lhr.rnd.model.PricingFileRecord;
import com.lhr.rnd.model.PricingPackagingItem;
import com.lhr.rnd.model.PricingReadyVersion;
import com.lhr.rnd.model.SampleRequest;
import com.lhr.rnd.model.ShipmentDetailView;
import com.lhr.rnd.model.ShipmentRecord;
import com.lhr.rnd.model.StoppedSampleProjectView;
import com.lhr.rnd.model.TestRecord;
import com.lhr.rnd.service.ApproveSampleRequestResult;
import com.lhr.rnd.service.FailInternalTestResult;
import com.lhr.rnd.service.NotifyFinanceResult;
import com.lhr.rnd.service.PassInternalTestResult;
import com.lhr.rnd.service.SampleWorkflowService;
import com.lhr.rnd.service.ShipmentFeedbackResult;
import com.lhr.rnd.service.SessionPrincipal;
import com.lhr.rnd.service.SubmitExperimentForTestResult;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class SampleWorkflowController {
    private final SampleWorkflowService workflowService;
    private final com.lhr.rnd.service.RequestIntakeService intake;

    public SampleWorkflowController(SampleWorkflowService workflowService, com.lhr.rnd.service.RequestIntakeService intake) {
        this.workflowService = workflowService;
        this.intake = intake;
    }

    @PostMapping("/sample-requests")
    public ApiResponse<?> createSampleRequest(@Valid @RequestBody CreateSampleRequestRequest request,HttpServletRequest http) {
        return ApiResponse.success(intake.create(request.command(),sessionPrincipal(http)));
    }

    @GetMapping("/sample-requests")
    public ApiResponse<?> sampleRequests(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) String sort,
            HttpServletRequest http
    ) {
        if (page != null || size != null) {
            var result=workflowService.requests(status, keyword, page, size, sort);
            return ApiResponse.success(new com.lhr.rnd.model.PagedResult<>(result.items().stream().map(r->intake.view(r,sessionPrincipal(http))).toList(),result.total(),result.page(),result.size(),result.totalPages()));
        }
        return ApiResponse.success(workflowService.requests(status, keyword).stream().map(r->intake.view(r,sessionPrincipal(http))).toList());
    }

    @GetMapping("/dashboard/overview")
    public ApiResponse<DashboardOverview> dashboardOverview() {
        return ApiResponse.success(workflowService.dashboardOverview());
    }

    @GetMapping("/sample-projects/stopped")
    public ApiResponse<List<StoppedSampleProjectView>> stoppedSampleProjects() {
        return ApiResponse.success(workflowService.stoppedProjects());
    }

    @PostMapping("/sample-requests/{id}/approve")
    public ApiResponse<ApproveSampleRequestResult> approveSampleRequest(
            @PathVariable String id,
            @Valid @RequestBody ApproveSampleRequestRequest request,
            HttpServletRequest http
    ) {
        return ApiResponse.success(intake.approve(id, request.versionNo(),sessionPrincipal(http)));
    }

    @PostMapping("/sample-requests/{id}/reject")
    public ApiResponse<?> rejectSampleRequest(@PathVariable String id,@Valid @RequestBody RejectSampleRequestRequest request,HttpServletRequest http) {
        return ApiResponse.success(intake.reject(id,request.versionNo(),request.comment(),sessionPrincipal(http)));
    }

    @PutMapping("/sample-requests/{id}/resubmit")
    public ApiResponse<?> resubmitSampleRequest(@PathVariable String id,@Valid @RequestBody ResubmitSampleRequestRequest request,HttpServletRequest http) {
        return ApiResponse.success(intake.resubmit(id,request.versionNo(),request.request().command(),sessionPrincipal(http)));
    }

    @GetMapping("/rnd-tasks/pool")
    public ApiResponse<List<RndTask>> taskPool() {
        return ApiResponse.success(workflowService.taskPool());
    }

    @GetMapping("/rnd-tasks")
    public ApiResponse<?> rndTasks(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String assigneeName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) String sort,
            HttpServletRequest request
    ) {
        var resolvedAssigneeName = resolveTaskAssigneeFilter(assigneeName, request);
        if (page != null || size != null) {
            return ApiResponse.success(workflowService.tasks(status, keyword, resolvedAssigneeName, page, size, sort));
        }
        return ApiResponse.success(workflowService.tasks(status, keyword, resolvedAssigneeName));
    }

    private String resolveTaskAssigneeFilter(String assigneeName, HttpServletRequest request) {
        if (assigneeName != null && !assigneeName.isBlank()) {
            return assigneeName.trim();
        }
        var principal = (SessionPrincipal) request.getAttribute(SessionAuthenticationInterceptor.SESSION_PRINCIPAL_ATTRIBUTE);
        if (principal != null && "RND_ENGINEER".equals(principal.role())) {
            return principal.name();
        }
        return null;
    }

    @GetMapping("/rnd-tasks/{id}/detail")
    public ApiResponse<RndTaskDetailView> rndTaskDetail(
            @PathVariable String id,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String operatorName,
            HttpServletRequest request
    ) {
        var principal = sessionPrincipal(request);
        if (principal != null) {
            return ApiResponse.success(workflowService.rndTaskDetail(id, principal));
        }
        return ApiResponse.success(workflowService.rndTaskDetail(id, role, operatorName));
    }

    @GetMapping("/rnd-tasks/{id}/test-records")
    public ApiResponse<List<TestRecord>> testRecords(@PathVariable String id) {
        return ApiResponse.success(workflowService.testRecordsForTask(id));
    }

    @PostMapping("/rnd-tasks/{id}/assign")
    public ApiResponse<RndTask> assignTask(
            @PathVariable String id,
            @Valid @RequestBody AssignRndTaskRequest request
    ) {
        return ApiResponse.success(workflowService.assignTask(
                id,
                request.assigneeName(),
                request.productOwnerName(),
                request.dueDate()
        ));
    }

    @PostMapping("/rnd-tasks/{id}/accept")
    public ApiResponse<RndTask> acceptTask(
            @PathVariable String id,
            @Valid @RequestBody AcceptRndTaskRequest request
    ) {
        return ApiResponse.success(workflowService.acceptTask(id, request.acceptedBy()));
    }

    @PostMapping("/rnd-tasks/{id}/experiment-form/draft")
    public ApiResponse<ExperimentForm> saveExperimentDraft(
            @PathVariable String id,
            @Valid @RequestBody SaveExperimentDraftRequest request,
            HttpServletRequest servletRequest
    ) {
        return ApiResponse.success(workflowService.saveExperimentDraft(new SampleWorkflowService.SaveExperimentDraftCommand(
                id,
                request.operatorName(),
                request.summary(),
                request.materials(),
                request.processSteps(),
                request.finishedOutputWeightKg(),
                request.finishedOutputQuantity(),
                request.finishedOutputUnit(),
                request.finishedYieldPercent(),
                request.yieldCalculationMode()
        ), requiredSessionPrincipal(servletRequest)));
    }

    @PostMapping("/experiment-forms/{id}/submit-test")
    public ApiResponse<SubmitExperimentForTestResult> submitExperimentForTest(
            @PathVariable String id,
            @Valid @RequestBody SubmitExperimentForTestRequest request,
            HttpServletRequest servletRequest
    ) {
        return ApiResponse.success(workflowService.submitExperimentForTest(id, request.testerName(), requiredSessionPrincipal(servletRequest)));
    }

    @PostMapping(value = "/experiment-forms/{id}/attachments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<ArchiveFileView> uploadExperimentAttachment(
            @PathVariable String id,
            @RequestParam("file") MultipartFile file,
            @RequestParam(required = false) String fileName,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String uploadedBy,
            @RequestParam(required = false) String remark
    ) {
        var resolvedFileName = fileName == null || fileName.isBlank() ? file.getOriginalFilename() : fileName;
        try {
            return ApiResponse.success(workflowService.archiveExperimentAttachment(
                    id,
                    resolvedFileName,
                    file.getBytes(),
                    category,
                    uploadedBy,
                    remark,
                    file.getContentType()
            ));
        } catch (IOException exception) {
            throw new BusinessException("ARCHIVE_FILE_READ_FAILED", "上传文件读取失败");
        }
    }

    @PostMapping("/test-assignments/{id}/pass")
    public ApiResponse<PassInternalTestResult> passInternalTest(
            @PathVariable String id,
            @Valid @RequestBody InternalTestDecisionRequest request,
            HttpServletRequest servletRequest
    ) {
        return ApiResponse.success(workflowService.passInternalTest(id, request.testerName(), request.comment(), requiredSessionPrincipal(servletRequest)));
    }

    @PostMapping("/test-assignments/{id}/fail-resample")
    public ApiResponse<FailInternalTestResult> failInternalTestForResample(
            @PathVariable String id,
            @Valid @RequestBody InternalTestDecisionRequest request,
            HttpServletRequest servletRequest
    ) {
        return ApiResponse.success(workflowService.failInternalTestForResample(id, request.testerName(), request.comment(), requiredSessionPrincipal(servletRequest)));
    }

    @PostMapping("/sample-versions/{id}/shipments")
    public ApiResponse<ShipmentRecord> createShipment(
            @PathVariable String id,
            @Valid @RequestBody CreateShipmentRequest request
    ) {
        return ApiResponse.success(workflowService.createShipment(new SampleWorkflowService.CreateShipmentCommand(
                id,
                request.quantity(),
                request.receiverName(),
                request.trackingNo(),
                request.remark()
        )));
    }

    @PostMapping("/shipments/{id}/feedback")
    public ApiResponse<ShipmentFeedbackResult> submitCustomerFeedback(
            @PathVariable String id,
            @Valid @RequestBody SubmitCustomerFeedbackRequest request
    ) {
        return ApiResponse.success(workflowService.submitCustomerFeedback(new SampleWorkflowService.SubmitCustomerFeedbackCommand(
                id,
                request.feedbackBy(),
                request.result(),
                request.comment()
        )));
    }

    @GetMapping("/shipments")
    public ApiResponse<List<ShipmentRecord>> shipments(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword
    ) {
        return ApiResponse.success(workflowService.shipments(status, keyword));
    }

    @GetMapping("/shipments/{id}/detail")
    public ApiResponse<ShipmentDetailView> shipmentDetail(
            @PathVariable String id,
            @RequestParam(required = false) String role
    ) {
        return ApiResponse.success(workflowService.shipmentDetail(id, role));
    }

    @PostMapping("/sample-versions/{id}/pricing-files")
    public ApiResponse<PricingFileRecord> generatePricingFile(@PathVariable String id) {
        return ApiResponse.success(workflowService.generatePricingFile(id));
    }

    @GetMapping("/sample-versions/pricing-ready")
    public ApiResponse<List<PricingReadyVersion>> pricingReadyVersions() {
        return ApiResponse.success(workflowService.pricingReadyVersions());
    }

    @GetMapping("/pricing-files")
    public ApiResponse<?> pricingFiles(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) String sort,
            HttpServletRequest request
    ) {
        var principal = sessionPrincipal(request);
        var role = principal == null ? null : principal.role();
        var operatorName = principal == null ? null : principal.name();
        if (page != null || size != null) {
            return ApiResponse.success(workflowService.pricingFiles(status, keyword, page, size, sort, role, operatorName));
        }
        return ApiResponse.success(workflowService.pricingFiles(status, keyword, role, operatorName));
    }

    @GetMapping("/pricing-files/{id}/detail")
    public ApiResponse<PricingFileDetailView> pricingFileDetail(
            @PathVariable String id,
            HttpServletRequest request
    ) {
        var principal = sessionPrincipal(request);
        return ApiResponse.success(workflowService.pricingFileDetail(
                id,
                principal == null ? null : principal.role(),
                principal == null ? null : principal.name()
        ));
    }

    @GetMapping("/pricing-files/{id}/packaging-items")
    public ApiResponse<List<PricingPackagingItem>> pricingPackagingItems(@PathVariable String id) {
        return ApiResponse.success(workflowService.pricingPackagingItems(id));
    }

    @PutMapping("/pricing-files/{id}/packaging-items")
    public ApiResponse<PricingFileRecord> confirmPricingPackaging(
            @PathVariable String id,
            @Valid @RequestBody ConfirmPricingPackagingRequest request,
            HttpServletRequest servletRequest
    ) {
        var principal = requiredSessionPrincipal(servletRequest);
        return ApiResponse.success(workflowService.confirmPricingPackaging(
                id, request.items(), principal.name(), principal.role()));
    }

    @PostMapping("/pricing-files/{id}/review")
    public ApiResponse<PricingFileRecord> reviewPricingFile(
            @PathVariable String id,
            @Valid @RequestBody ReviewPricingFileRequest request,
            HttpServletRequest servletRequest
    ) {
        var principal = requiredSessionPrincipal(servletRequest);
        return ApiResponse.success(workflowService.reviewPricingFile(
                id, request.decision(), principal.name(), principal.role(), request.comment()));
    }

    @PostMapping("/pricing-files/{id}/notify-finance")
    public ApiResponse<NotifyFinanceResult> notifyFinance(
            @PathVariable String id,
            @Valid @RequestBody NotifyFinanceRequest request,
            HttpServletRequest servletRequest
    ) {
        requiredSessionPrincipal(servletRequest);
        return ApiResponse.success(workflowService.notifyFinance(id, request.recipientName(), request.remark()));
    }

    @PostMapping("/pricing-files/{id}/receive")
    public ApiResponse<PricingFileRecord> receivePricingFile(
            @PathVariable String id,
            @Valid @RequestBody ReceivePricingFileRequest request,
            HttpServletRequest servletRequest
    ) {
        var principal = requiredSessionPrincipal(servletRequest);
        return ApiResponse.success(workflowService.receivePricingFile(id, principal.name()));
    }

    @GetMapping("/pricing-files/{id}/download")
    public ResponseEntity<byte[]> downloadPricingFile(@PathVariable String id, HttpServletRequest request) {
        var principal = sessionPrincipal(request);
        var file = workflowService.downloadPricingFile(
                id,
                principal == null ? null : principal.role(),
                principal == null ? null : principal.name()
        );
        var encodedFileName = URLEncoder.encode(file.fileName(), StandardCharsets.UTF_8).replace("+", "%20");
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename*=UTF-8''" + encodedFileName)
                .body(file.content());
    }

    private String resolvedRole(HttpServletRequest request) {
        var principal = sessionPrincipal(request);
        return principal == null ? null : principal.role();
    }

    private SessionPrincipal sessionPrincipal(HttpServletRequest request) {
        return (SessionPrincipal) request.getAttribute(SessionAuthenticationInterceptor.SESSION_PRINCIPAL_ATTRIBUTE);
    }

    private SessionPrincipal requiredSessionPrincipal(HttpServletRequest request) {
        var principal = sessionPrincipal(request);
        if (principal == null) {
            throw new BusinessException("SESSION_PRINCIPAL_REQUIRED", "核价审核必须使用服务端会话身份");
        }
        return principal;
    }

    @GetMapping("/sample-versions/{id}/process-steps")
    public ApiResponse<List<ExperimentProcessStep>> processSteps(@PathVariable String id) {
        return ApiResponse.success(workflowService.processStepsForVersion(id));
    }

    @GetMapping("/sample-projects/{projectId}/version-timeline")
    public ApiResponse<List<SampleVersionTimelineItem>> versionTimeline(@PathVariable String projectId) {
        return ApiResponse.success(workflowService.versionTimeline(projectId));
    }

    @GetMapping("/sample-requests/{id}")
    public ApiResponse<?> sampleRequestDetail(@PathVariable String id,HttpServletRequest http) {
        return ApiResponse.success(intake.view(workflowService.requestDetail(id),sessionPrincipal(http)));
    }

    @GetMapping("/sample-versions/{id}/archive-files")
    public ApiResponse<List<ArchiveFileView>> archiveFiles(@PathVariable String id, HttpServletRequest request) {
        var principal = sessionPrincipal(request);
        return ApiResponse.success(workflowService.archiveFiles(
                id,
                principal == null ? null : principal.role(),
                principal == null ? null : principal.name()
        ));
    }

    @GetMapping("/archive-files/{id}/download")
    public ResponseEntity<byte[]> downloadArchiveFile(@PathVariable String id, HttpServletRequest request) {
        var principal = sessionPrincipal(request);
        var file = workflowService.downloadArchiveFile(
                id,
                principal == null ? null : principal.role(),
                principal == null ? null : principal.name()
        );
        var encodedFileName = URLEncoder.encode(file.fileName(), StandardCharsets.UTF_8).replace("+", "%20");
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename*=UTF-8''" + encodedFileName)
                .body(file.content());
    }
}
