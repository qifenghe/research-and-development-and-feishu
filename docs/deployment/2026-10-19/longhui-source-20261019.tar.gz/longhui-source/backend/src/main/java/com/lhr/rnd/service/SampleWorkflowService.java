package com.lhr.rnd.service;
import com.lhr.rnd.model.ProcessPlan;

import com.lhr.rnd.api.BusinessException;
import com.lhr.rnd.domain.SampleAction;
import com.lhr.rnd.domain.ExperimentCalculationService;
import com.lhr.rnd.domain.SampleStatus;
import com.lhr.rnd.domain.SampleStatusMachine;
import com.lhr.rnd.domain.SampleVersionCode;
import com.lhr.rnd.model.CustomerFeedback;
import com.lhr.rnd.model.CustomerFeedbackResult;
import com.lhr.rnd.model.DashboardOverview;
import com.lhr.rnd.model.DashboardPricingFileItem;
import com.lhr.rnd.model.DashboardTaskItem;
import com.lhr.rnd.model.DetailAction;
import com.lhr.rnd.model.DetailFieldGroup;
import com.lhr.rnd.model.FinanceNotification;
import com.lhr.rnd.model.FinanceNotificationStatus;
import com.lhr.rnd.model.PagedResult;
import com.lhr.rnd.model.RndTask;
import com.lhr.rnd.model.RndTaskDetailView;
import com.lhr.rnd.model.RndTaskStatus;
import com.lhr.rnd.model.ArchiveFileView;
import com.lhr.rnd.model.ExperimentForm;
import com.lhr.rnd.model.ExperimentFormStatus;
import com.lhr.rnd.model.ExperimentMaterial;
import com.lhr.rnd.model.ExperimentProcessStep;
import com.lhr.rnd.model.SampleVersionTimelineItem;
import com.lhr.rnd.model.PricingFileRecord;
import com.lhr.rnd.model.PricingReadyVersion;
import com.lhr.rnd.model.PricingFileDetailView;
import com.lhr.rnd.model.PricingFileStatus;
import com.lhr.rnd.model.PricingProcessSource;
import com.lhr.rnd.model.ProcessRevision;
import com.lhr.rnd.model.PricingPackagingItem;
import com.lhr.rnd.model.PricingPackagingSource;
import com.lhr.rnd.model.PricingPackagingStatus;
import com.lhr.rnd.model.PackagingTemplateItem;
import com.lhr.rnd.model.SampleProject;
import com.lhr.rnd.model.SampleProjectSummary;
import com.lhr.rnd.model.SampleRequest;
import com.lhr.rnd.model.SampleVersion;
import com.lhr.rnd.model.ShipmentDetailView;
import com.lhr.rnd.model.ShipmentRecord;
import com.lhr.rnd.model.ShipmentStatus;
import com.lhr.rnd.model.StoppedSampleProjectView;
import com.lhr.rnd.model.TestAssignment;
import com.lhr.rnd.model.TestAssignmentStatus;
import com.lhr.rnd.model.TestRecord;
import com.lhr.rnd.model.YieldCalculationMode;
import com.lhr.rnd.persistence.entity.ArchiveFileEntity;
import com.lhr.rnd.persistence.entity.CustomerFeedbackEntity;
import com.lhr.rnd.persistence.entity.ExperimentFormEntity;
import com.lhr.rnd.persistence.entity.ExperimentMaterialEntity;
import com.lhr.rnd.persistence.entity.ExperimentProcessEntity;
import com.lhr.rnd.persistence.entity.FinanceNotificationEntity;
import com.lhr.rnd.persistence.entity.PricingFileEntity;
import com.lhr.rnd.persistence.entity.PricingPackagingItemEntity;
import com.lhr.rnd.persistence.entity.PackagingTemplateItemEntity;
import com.lhr.rnd.persistence.entity.RndTaskEntity;
import com.lhr.rnd.persistence.entity.SampleProjectEntity;
import com.lhr.rnd.persistence.entity.SampleRequestEntity;
import com.lhr.rnd.persistence.entity.SampleVersionEntity;
import com.lhr.rnd.persistence.entity.ShipmentRecordEntity;
import com.lhr.rnd.persistence.entity.TestAssignmentEntity;
import com.lhr.rnd.persistence.entity.TestRecordEntity;
import com.lhr.rnd.persistence.repository.ArchiveFileRepository;
import com.lhr.rnd.persistence.repository.CustomerFeedbackRepository;
import com.lhr.rnd.persistence.repository.ExperimentFormRepository;
import com.lhr.rnd.persistence.repository.ExperimentMaterialRepository;
import com.lhr.rnd.persistence.repository.ExperimentProcessRepository;
import com.lhr.rnd.persistence.repository.FinanceNotificationRepository;
import com.lhr.rnd.persistence.repository.PricingFileRepository;
import com.lhr.rnd.persistence.repository.PricingPackagingItemRepository;
import com.lhr.rnd.persistence.repository.PackagingTemplateItemRepository;
import com.lhr.rnd.persistence.repository.RndTaskRepository;
import com.lhr.rnd.persistence.repository.UserAccountRepository;
import com.lhr.rnd.persistence.repository.SampleProjectRepository;
import com.lhr.rnd.persistence.repository.SampleRequestRepository;
import com.lhr.rnd.persistence.repository.SampleVersionRepository;
import com.lhr.rnd.persistence.repository.ShipmentRecordRepository;
import com.lhr.rnd.persistence.repository.TestAssignmentRepository;
import com.lhr.rnd.persistence.repository.TestRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.Clock;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.UUID;

@Service
public class SampleWorkflowService {
    private static final int MAX_ATTACHMENT_SIZE_BYTES = 10 * 1024 * 1024;
    private static final String DEFAULT_FINANCE_RECIPIENT = "财务核价员";
    private static final String AUTO_FINANCE_REMARK = "核价文件已审核通过，系统自动移交财务核价";
    private static final Set<String> ALLOWED_ATTACHMENT_CONTENT_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/webp",
            "application/pdf",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );

    private final Clock clock;
    private final PricingFileService pricingFileService = new PricingFileService();
    private final PricingPackagingService pricingPackagingService = new PricingPackagingService();
    private final ExperimentCalculationService experimentCalculationService = new ExperimentCalculationService();
    private final LocalArchiveStorageService archiveStorageService;
    private final FeishuIntegrationService feishuIntegrationService;
    private final WorkflowDrivenSampleStatusMachine workflowStatusMachine;
    private final SampleRequestRepository sampleRequestRepository;
    private final SampleProjectRepository sampleProjectRepository;
    private final SampleVersionRepository sampleVersionRepository;
    private final RndTaskRepository rndTaskRepository;
    private final ExperimentFormRepository experimentFormRepository;
    private final ExperimentMaterialRepository experimentMaterialRepository;
    private final ExperimentProcessRepository experimentProcessRepository;
    private final AuditLogService auditLogService;
    private final TestAssignmentRepository testAssignmentRepository;
    private final TestRecordRepository testRecordRepository;
    private final ShipmentRecordRepository shipmentRecordRepository;
    private final CustomerFeedbackRepository customerFeedbackRepository;
    private final PricingFileRepository pricingFileRepository;
    private final PricingPackagingItemRepository pricingPackagingItemRepository;
    private final PackagingTemplateItemRepository packagingTemplateItemRepository;
    private final FinanceNotificationRepository financeNotificationRepository;
    private final ArchiveFileRepository archiveFileRepository;
    private final PricingArchiveCleanupLedgerService pricingArchiveCleanupLedger;
    @Autowired(required = false) private UserAccountRepository userAccountRepository;
    @Autowired(required = false) private ProcessRevisionService processRevisionService;
    @Autowired(required = false) private TrialPromotionService trialPromotionService;
    @Autowired(required = false) private PricingBasisService pricingBasisService;
    @Autowired private MaterialReferenceService materialReferences;

    @Transactional
    public byte[] previewPricingBasis(String id, int expectedVersion, SessionPrincipal principal) {
        requireBasisAccess(id, principal, true);
        var view=pricingBasisService.load(id,pricingBasisSource(id));
        if(view.version()!=expectedVersion || view.stale()) throw new BusinessException("PRICING_BASIS_CONFLICT","核价数据或来源已更新，请重新加载");
        var preview = view.draft().signature() == null ? view.draft().withSignature(com.lhr.rnd.model.DocumentSignature.pending(principal.name(),now().toString())) : view.draft();
        return new PricingMaterialListRenderer().render(preview,view.calculation(),true);
    }

    @Transactional
    public PricingFileRecord generateConfirmedPricingBasis(String id, int expectedVersion, SessionPrincipal principal) {
        requireBasisAccess(id, principal, true);
        var source=pricingBasisSource(id);
        var view=pricingBasisService.load(id,source);
        if(view.version()!=expectedVersion) throw new BusinessException("PRICING_BASIS_CONFLICT","核价数据已更新，请重新加载");
        var draft=pricingBasisService.confirmed(id,source);
        return confirmPricingPackaging(id,basisPackaging(id,draft),principal.name(),principal.role());
    }

    private List<PricingPackagingItem> basisPackaging(String id,com.lhr.rnd.model.PricingBasisDraft draft) {
        var original=pricingPackagingItems(id);var values=new ArrayList<PricingPackagingItem>();
        for(var p:draft.packaging()) {
            if(p.quantity()!=null && p.quantity().signum()==0) continue;
            var old=original.stream().filter(x->Objects.equals(x.id(),p.id())).findFirst().orElse(null);
            values.add(new PricingPackagingItem(p.id(),id,values.size()+1,old==null?PricingPackagingSource.MANUAL:old.source(),p.materialCode(),p.materialName(),p.quantity(),p.specification(),p.conversionRule(),p.remark(),PricingPackagingStatus.CONFIRMED,p.adjustmentReason(),p.quantityUnit()));
        }
        return values;
    }

    @Transactional
    public PricingBasisService.View pricingBasis(String id, SessionPrincipal principal) {
        requireBasisAccess(id, principal, false);
        return pricingBasisService.load(id, pricingBasisSource(id));
    }

    @Transactional
    public PricingBasisService.View savePricingBasis(String id, int expectedVersion, com.lhr.rnd.model.PricingBasisDraft draft, SessionPrincipal principal) {
        requireBasisAccess(id, principal, true);
        return pricingBasisService.save(id, expectedVersion, draft, pricingBasisSource(id), principal.name());
    }

    @Transactional
    public PricingBasisService.View confirmPricingBasis(String id, int expectedVersion, SessionPrincipal principal) {
        requireBasisAccess(id, principal, true);
        return pricingBasisService.confirm(id, expectedVersion, pricingBasisSource(id), principal.name());
    }

    private void requireBasisAccess(String id, SessionPrincipal principal, boolean write) {
        if (principal == null) throw new BusinessException("SESSION_PRINCIPAL_REQUIRED", "必须使用服务端会话身份");
        if (!hasRole(principal.role(), "RND_DIRECTOR", "RND_ENGINEER", "RND_ASSISTANT", "FINANCE", "MANAGER", "ADMIN", "SYSTEM_ADMIN", "SUPER_ADMIN"))
            throw new BusinessException("PRICING_BASIS_FORBIDDEN", "当前角色不能访问核价数据");
        var record = lockedPricingFile(id);
        pricingFileDetail(id, principal.role(), principal.name());
        if (write) ensurePricingReviewer(record, principal.name(), principal.role());
    }

    private com.lhr.rnd.model.PricingBasisDraft pricingBasisSource(String id) {
        var record = requiredPricingFile(id);
        var version = requiredVersion(record.versionId());
        var form = lockedExperimentForm(record.versionId());
        var revision = latestFormalPricingRevision(form);
        var materials = new java.util.ArrayList<com.lhr.rnd.model.PricingBasisDraft.Material>();
        BigDecimal mainOutput = null;
        if (revision != null) {
            for (var major : revision.snapshot().majorProcesses().stream().sorted(java.util.Comparator.comparingInt(ProcessPlan.MajorProcess::sequence)).toList())
                for (var step : major.steps().stream().sorted(java.util.Comparator.comparingInt(ProcessPlan.MinorStep::sequence)).toList()) {
                    for (var m : step.materials()) if ("EXTERNAL".equals(m.sourceType()) && !"PACKAGING".equals(m.materialRole()))
                        materials.add(new com.lhr.rnd.model.PricingBasisDraft.Material(m.id(), major.id(), step.id(), m.id(), major.processName(), m.materialCode(), m.materialName(), m.materialRole(), "EXTERNAL", m.weightKg(), null, m.weightKg(), null, null, null, m.remark(),step.sequence()+". "+step.stepName()));
                    if (step.outputs() != null) for (var out : step.outputs()) if (out.primaryOutput()) mainOutput = out.weightKg();
                }
        } else {
            for (int i=0;i<form.materials().size();i++) {
                var m=form.materials().get(i); var key="legacy-"+i;
                materials.add(new com.lhr.rnd.model.PricingBasisDraft.Material(key,"legacy",key,key,m.stage(),m.materialCode(),m.materialName(),m.primaryMaterial()?"PRIMARY":"AUXILIARY","EXTERNAL",m.weightKg(),null,m.weightKg(),m.utilizationRate(),null,null,m.remark(),"旧版试验单第 "+(i+1)+" 行"));
            }
            // Legacy total finished weight is not presumed to be pure primary-material output.
        }
        var header = new com.lhr.rnd.model.PricingBasisDraft.Header("江西龙汇肉制品有限责任公司",version.productName(),version.specification(),version.ownerName(),version.authorName(),version.productType(),null,version.versionCode(),version.effectiveDate()==null?null:version.effectiveDate().toString());
        var packaging=pricingPackagingItems(id).stream().map(p->new com.lhr.rnd.model.PricingBasisDraft.Packaging(p.id(),p.materialCode(),p.materialName(),null,p.quantity(),p.quantityUnit(),p.packageSpec(),p.conversionRule(),p.remark(),null)).toList();
        return new com.lhr.rnd.model.PricingBasisDraft(1,revision==null?"legacy:"+form.id()+":"+form.savedAt():revision.id(),header,materials,mainOutput,materials.stream().filter(m->"PRIMARY".equals(m.role())).map(com.lhr.rnd.model.PricingBasisDraft.Material::id).toList(),null,form.finishedOutputWeightKg(),version.unitWeightKg(),bagsPerBox(version.specification()),"袋".equals(form.finishedOutputUnit()) && form.finishedOutputQuantity()!=null ? form.finishedOutputQuantity().intValueExact() : null,packaging);
    }
    private final Map<String, SampleRequest> requests = new LinkedHashMap<>();
    private final Map<String, SampleProject> projects = new LinkedHashMap<>();
    private final Map<String, SampleVersion> versions = new LinkedHashMap<>();
    private final Map<String, RndTask> tasks = new LinkedHashMap<>();
    private final Map<String, ExperimentForm> experimentForms = new LinkedHashMap<>();
    private final Map<String, TestAssignment> testAssignments = new LinkedHashMap<>();
    private final Map<String, TestRecord> testRecords = new LinkedHashMap<>();
    private final Map<String, ShipmentRecord> shipments = new LinkedHashMap<>();
    private final Map<String, CustomerFeedback> customerFeedbacks = new LinkedHashMap<>();
    private final Map<String, PricingFileRecord> pricingFiles = new LinkedHashMap<>();
    private final Map<String, FinanceNotification> financeNotifications = new LinkedHashMap<>();

    private int requestSequence = 1;
    private int taskSequence = 1;
    private int experimentSequence = 1;
    private int testAssignmentSequence = 1;
    private int testRecordSequence = 1;
    private int shipmentSequence = 1;
    private int customerFeedbackSequence = 1;
    private int pricingFileSequence = 1;
    private int financeNotificationSequence = 1;

    public SampleWorkflowService() {
        this(Clock.systemDefaultZone(), new LocalArchiveStorageService(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    }

    SampleWorkflowService(Clock clock) {
        this(clock, new LocalArchiveStorageService(), null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    }

    @Autowired
    public SampleWorkflowService(
            LocalArchiveStorageService archiveStorageService,
            FeishuIntegrationService feishuIntegrationService,
            WorkflowDrivenSampleStatusMachine workflowStatusMachine,
            SampleRequestRepository sampleRequestRepository,
            SampleProjectRepository sampleProjectRepository,
            SampleVersionRepository sampleVersionRepository,
            RndTaskRepository rndTaskRepository,
            ExperimentFormRepository experimentFormRepository,
            ExperimentMaterialRepository experimentMaterialRepository,
            ExperimentProcessRepository experimentProcessRepository,
            AuditLogService auditLogService,
            TestAssignmentRepository testAssignmentRepository,
            TestRecordRepository testRecordRepository,
            ShipmentRecordRepository shipmentRecordRepository,
            CustomerFeedbackRepository customerFeedbackRepository,
            PricingFileRepository pricingFileRepository,
            PricingPackagingItemRepository pricingPackagingItemRepository,
            PackagingTemplateItemRepository packagingTemplateItemRepository,
            FinanceNotificationRepository financeNotificationRepository,
            ArchiveFileRepository archiveFileRepository,
            PricingArchiveCleanupLedgerService pricingArchiveCleanupLedger
    ) {
        this(
                Clock.systemDefaultZone(),
                archiveStorageService,
                feishuIntegrationService,
                workflowStatusMachine,
                sampleRequestRepository,
                sampleProjectRepository,
                sampleVersionRepository,
                rndTaskRepository,
                experimentFormRepository,
                experimentMaterialRepository,
                experimentProcessRepository,
                auditLogService,
                testAssignmentRepository,
                testRecordRepository,
                shipmentRecordRepository,
                customerFeedbackRepository,
                pricingFileRepository,
                pricingPackagingItemRepository,
                packagingTemplateItemRepository,
                financeNotificationRepository,
                archiveFileRepository,
                pricingArchiveCleanupLedger
        );
    }

    private SampleWorkflowService(
            Clock clock,
            LocalArchiveStorageService archiveStorageService,
            FeishuIntegrationService feishuIntegrationService,
            WorkflowDrivenSampleStatusMachine workflowStatusMachine,
            SampleRequestRepository sampleRequestRepository,
            SampleProjectRepository sampleProjectRepository,
            SampleVersionRepository sampleVersionRepository,
            RndTaskRepository rndTaskRepository,
            ExperimentFormRepository experimentFormRepository,
            ExperimentMaterialRepository experimentMaterialRepository,
            ExperimentProcessRepository experimentProcessRepository,
            AuditLogService auditLogService,
            TestAssignmentRepository testAssignmentRepository,
            TestRecordRepository testRecordRepository,
            ShipmentRecordRepository shipmentRecordRepository,
            CustomerFeedbackRepository customerFeedbackRepository,
            PricingFileRepository pricingFileRepository,
            PricingPackagingItemRepository pricingPackagingItemRepository,
            PackagingTemplateItemRepository packagingTemplateItemRepository,
            FinanceNotificationRepository financeNotificationRepository,
            ArchiveFileRepository archiveFileRepository,
            PricingArchiveCleanupLedgerService pricingArchiveCleanupLedger
    ) {
        this.clock = clock;
        this.archiveStorageService = archiveStorageService;
        this.feishuIntegrationService = feishuIntegrationService;
        this.workflowStatusMachine = workflowStatusMachine;
        this.sampleRequestRepository = sampleRequestRepository;
        this.sampleProjectRepository = sampleProjectRepository;
        this.sampleVersionRepository = sampleVersionRepository;
        this.rndTaskRepository = rndTaskRepository;
        this.experimentFormRepository = experimentFormRepository;
        this.experimentMaterialRepository = experimentMaterialRepository;
        this.experimentProcessRepository = experimentProcessRepository;
        this.auditLogService = auditLogService;
        this.testAssignmentRepository = testAssignmentRepository;
        this.testRecordRepository = testRecordRepository;
        this.shipmentRecordRepository = shipmentRecordRepository;
        this.customerFeedbackRepository = customerFeedbackRepository;
        this.pricingFileRepository = pricingFileRepository;
        this.pricingPackagingItemRepository = pricingPackagingItemRepository;
        this.packagingTemplateItemRepository = packagingTemplateItemRepository;
        this.financeNotificationRepository = financeNotificationRepository;
        this.archiveFileRepository = archiveFileRepository;
        this.pricingArchiveCleanupLedger = pricingArchiveCleanupLedger;
    }

    @Transactional
    public synchronized SampleRequest createRequest(CreateSampleRequestCommand command) {
        var requestId = nextAvailableId("REQ", requestSequence++, requests, sampleRequestRepository);
        var sampleNo = "YP20260618" + requestId.substring(4);
        var request = new SampleRequest(
                requestId,
                sampleNo,
                command.productName(),
                command.productType(),
                command.customerName(),
                command.specification(),
                command.applicationScenario(),
                command.flavorRequirement(),
                command.creatorName(),
                SampleStatus.PENDING_REVIEW,
                now(),
                command.referenceSampleProvided(), command.cutShape(), command.mainMaterialRequirement(), command.textureRequirement(), command.packagingRequirement(), command.storageRequirement(), command.customerTargetPrice(), command.monthlyDemand(), command.specialRequirements(), command.referenceMarketPrice(), command.additionalNotes()
        );

        requests.put(request.id(), request);
        persistRequest(request);
        return request;
    }

    @Transactional
    public synchronized ApproveSampleRequestResult approveRequest(String requestId, String reviewerName) {
        var request = requestDetail(requestId);
        if (request.status() != SampleStatus.PENDING_REVIEW) {
            throw new BusinessException("SAMPLE_REQUEST_STATUS_ILLEGAL", "当前需求状态不可审核");
        }

        var projectStatus = transitionSampleStatus(request.status(), SampleAction.APPROVE_REQUEST);
        var approvedRequest = new SampleRequest(
                request.id(),
                request.sampleNo(),
                request.productName(),
                request.productType(),
                request.customerName(),
                request.specification(),
                request.applicationScenario(),
                request.flavorRequirement(),
                request.creatorName(),
                projectStatus,
                request.createdAt(),
                request.referenceSampleProvided(), request.cutShape(), request.mainMaterialRequirement(), request.textureRequirement(), request.packagingRequirement(), request.storageRequirement(), request.customerTargetPrice(), request.monthlyDemand(), request.specialRequirements(), request.referenceMarketPrice(), request.additionalNotes()
        );
        var project = new SampleProject(
                nextAvailableId("PROJ", projects.size() + 1, projects, sampleProjectRepository),
                request.sampleNo(),
                request.productName(),
                request.productType(),
                request.customerName(),
                request.specification(),
                request.applicationScenario(),
                request.flavorRequirement(),
                projectStatus,
                now()
        );
        var versionCode = SampleVersionCode.fromNumber(0).code();
        var version = SampleVersion.builder()
                .id(nextAvailableId("VER", versions.size() + 1, versions, sampleVersionRepository))
                .projectId(project.id())
                .sampleNo(request.sampleNo())
                .productName(request.productName())
                .productType(request.productType())
                .specification(request.specification())
                .applicationScenario(request.applicationScenario())
                .flavorRequirement(request.flavorRequirement())
                .versionNo(versionCode)
                .versionNumber(0)
                .versionCode(versionCode)
                .ownerName(reviewerName)
                .authorName(request.creatorName())
                .createdAt(now())
                .build();
        var task = new RndTask(
                nextAvailableId("TASK", taskSequence, tasks, rndTaskRepository),
                project.id(),
                version.id(),
                request.sampleNo(),
                request.productName(),
                version.versionCode(),
                RndTaskStatus.PENDING_ASSIGNMENT,
                null,
                null,
                null,
                now(),
                null
        );
        taskSequence++;

        requests.put(approvedRequest.id(), approvedRequest);
        projects.put(project.id(), project);
        versions.put(version.id(), version);
        tasks.put(task.id(), task);
        persistApprovedWorkflow(approvedRequest, project, version, task);
        return new ApproveSampleRequestResult(project, version, task);
    }

    public synchronized List<RndTask> taskPool() {
        restoreTaskCache();
        return tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.PENDING_ASSIGNMENT)
                .toList();
    }

    @Transactional
    public synchronized RndTask assignTask(String taskId, String assigneeName, LocalDate dueDate) {
        return assignTask(taskId, assigneeName, assigneeName, dueDate);
    }

    @Transactional
    public synchronized RndTask assignTask(
            String taskId,
            String assigneeName,
            String productOwnerName,
            LocalDate dueDate
    ) {
        var task = requiredTask(taskId);
        if (task.status() != RndTaskStatus.PENDING_ASSIGNMENT) {
            throw new BusinessException("RND_TASK_STATUS_ILLEGAL", "当前任务状态不可分发");
        }
        var assigneeUserId = resolveExactlyOneActiveAssignee(assigneeName);
        var nextStatus = taskStatusAfter(SampleStatus.PENDING_ASSIGNMENT, SampleAction.ASSIGN_TASK);
        var assigned = task.assign(assigneeName, normalizeProductOwnerName(productOwnerName, assigneeName), dueDate, now())
                .withStatus(nextStatus);
        persistAssignedTask(assigned, assigneeUserId);
        cacheWithRollback(() -> tasks.put(taskId, assigned), () -> tasks.put(taskId, task));
        notifyTaskAssigned(assigned);
        return assigned;
    }

    @Transactional
    public synchronized RndTask acceptTask(String taskId, String acceptedBy) {
        var task = requiredTask(taskId);
        if (task.status() != RndTaskStatus.PENDING_ACCEPTANCE) {
            throw new BusinessException("RND_TASK_STATUS_ILLEGAL", "当前任务状态不可接受");
        }
        if (!acceptedBy.equals(task.assigneeName())) {
            throw new BusinessException("RND_TASK_ASSIGNEE_MISMATCH", "只能由被分发的研发人员接受任务");
        }
        var acceptedAt = now();
        var nextStatus = taskStatusAfter(SampleStatus.PENDING_ACCEPTANCE, SampleAction.ACCEPT_TASK);
        var accepted = task.accept(acceptedAt).withStatus(nextStatus);
        tasks.put(taskId, accepted);
        persistAcceptedTask(accepted, acceptedAt);
        return accepted;
    }

    @Transactional
    public synchronized ExperimentForm saveExperimentDraft(SaveExperimentDraftCommand command) {
        return saveExperimentDraftInternal(command);
    }

    @Transactional
    public synchronized ExperimentForm saveExperimentDraft(SaveExperimentDraftCommand command, SessionPrincipal principal) {
        requireTaskWriteAccess(command.taskId(), principal);
        return saveExperimentDraftInternal(new SaveExperimentDraftCommand(command.taskId(), principal.name(), command.summary(),
                command.materials(), command.processSteps(), command.finishedOutputWeightKg(), command.finishedOutputQuantity(),
                command.finishedOutputUnit(), command.finishedYieldPercent(), command.yieldCalculationMode()));
    }

    private ExperimentForm saveExperimentDraftInternal(SaveExperimentDraftCommand command) {
        var task = requiredTask(command.taskId());
        if (task.status() != RndTaskStatus.SAMPLING) {
            throw new BusinessException("RND_TASK_STATUS_ILLEGAL", "任务接受后才能填写实验单");
        }

        var existing = currentExperimentForm(command.taskId(), task.versionId());
        var id = existing == null ? nextExperimentFormId() : existing.id();
        var materials = normalizeExperimentMaterials(command.materials());
        if (materialReferences != null) materials = materialReferences.resolveLegacy(materials, existing == null ? List.of() : existing.materials());
        else if (materials.stream().anyMatch(m -> m.catalogMaterialId() != null)) throw new BusinessException("MATERIAL_CATALOG_UNAVAILABLE", "物料库服务不可用");
        validateExperimentMaterials(materials);
        materials = recalculateFormulaRatios(materials);
        var processSteps = recalculateProcessLosses(command.processSteps());
        var finishedOutputUnit = normalizeFinishedOutputUnit(command.finishedOutputUnit());
        var finishedOutputQuantity = com.lhr.rnd.domain.FinishedOutputValidator.validate(command.finishedOutputWeightKg(), command.finishedOutputQuantity(), finishedOutputUnit);
        var yieldCalculationMode = command.yieldCalculationMode() == null
                ? YieldCalculationMode.SELECTED_PRIMARY_MATERIALS
                : command.yieldCalculationMode();
        var yieldBasisWeight = experimentCalculationService.yieldBasisWeight(materials, yieldCalculationMode);
        var finishedYieldPercent = experimentCalculationService.finishedYield(
                command.finishedOutputWeightKg(), yieldBasisWeight);
        var draft = new ExperimentForm(
                id,
                task.id(),
                task.projectId(),
                task.versionId(),
                task.sampleNo(),
                task.productName(),
                task.versionCode(),
                ExperimentFormStatus.DRAFT,
                command.operatorName(),
                command.summary(),
                materials,
                processSteps,
                command.finishedOutputWeightKg(),
                finishedOutputQuantity,
                finishedOutputUnit,
                yieldCalculationMode,
                finishedYieldPercent,
                now(),
                null
        );
        persistExperimentDraft(draft);
        if (auditLogService != null) {
            auditLogService.record("EXPERIMENT_FORM", draft.id(), "SAVE_DRAFT", command.operatorName(),
                    "taskId=" + task.id() + ", processSteps=" + processSteps.size());
        }
        cacheAfterCommit(() -> experimentForms.put(draft.id(), draft));
        return draft;
    }

    @Transactional
    public synchronized SubmitExperimentForTestResult submitExperimentForTest(String experimentFormId, String testerName) {
        return submitExperimentForTestInternal(experimentFormId, testerName, null);
    }

    @Transactional
    public synchronized SubmitExperimentForTestResult submitExperimentForTest(String experimentFormId, String testerName,
                                                                               SessionPrincipal principal) {
        var form = requiredExperimentForm(experimentFormId);
        requireTaskWriteAccess(form.taskId(), principal);
        return submitExperimentForTestInternal(experimentFormId, testerName, principal);
    }

    private SubmitExperimentForTestResult submitExperimentForTestInternal(String experimentFormId, String testerName,
                                                                           SessionPrincipal principal) {
        lockExperimentFormForSubmission(experimentFormId);
        var form = requiredExperimentForm(experimentFormId);
        if (form.status() != ExperimentFormStatus.DRAFT) {
            throw new BusinessException("EXPERIMENT_FORM_STATUS_ILLEGAL", "只有草稿实验单可以提交测试");
        }
        validateSubmittableExperiment(form);
        var formalRevision = principal == null || processRevisionService == null ? null : processRevisionService.requireCurrentFormalForTest(experimentFormId);
        if (principal != null && formalRevision == null) {
            throw new BusinessException("PROCESS_FORMAL_REVISION_REQUIRED", "通知测试前请先正式提交当前工艺版本");
        }
        if (formalRevision == null && materialReferences != null) {
            for (var material : form.materials()) materialReferences.requireActiveReference(new MaterialReferenceService.Reference(
                    material.catalogMaterialId(), material.materialCode(), material.materialName(), material.catalogSpecification(), material.catalogUnit()));
        }
        var nextTaskStatus = taskStatusAfter(SampleStatus.SAMPLING, SampleAction.SUBMIT_EXPERIMENT);
        var submitted = form.submit(now());

        var task = tasks.get(submitted.taskId());
        if (task == null && rndTaskRepository != null) {
            task = rndTaskRepository.findById(submitted.taskId())
                    .map(this::hydrateRndTask)
                    .orElse(null);
        }
        RndTask pendingTestTask = null;
        if (task != null) {
            pendingTestTask = new RndTask(
                    task.id(),
                    task.projectId(),
                    task.versionId(),
                    task.sampleNo(),
                    task.productName(),
                    task.versionCode(),
                    nextTaskStatus,
                    task.assigneeName(),
                    task.productOwnerName(),
                    task.dueDate(),
                    task.createdAt(),
                    task.assignedAt()
            );
        }

        var tester = principal == null ? new TesterIdentity(null, testerName) : resolveTester(testerName);
        var assignment = new TestAssignment(
                nextTestAssignmentId(),
                submitted.id(),
                submitted.taskId(),
                submitted.versionId(),
                formalRevision == null ? null : formalRevision.id(),
                tester.name(),
                tester.userId(),
                TestAssignmentStatus.PENDING_TEST,
                now()
        );
        persistSubmittedExperiment(submitted, assignment);
        if (auditLogService != null && principal != null) {
            auditLogService.record("EXPERIMENT_FORM", submitted.id(), "SUBMIT_FOR_TEST", principal.name(), principal.userId(),
                    "testAssignmentId=%s;processRevisionId=%s;testerName=%s".formatted(assignment.id(), formalRevision.id(), tester.name()));
        }
        var taskToCache = pendingTestTask;
        cacheAfterCommit(() -> {
            experimentForms.put(submitted.id(), submitted);
            testAssignments.put(assignment.id(), assignment);
            if (taskToCache != null) {
                tasks.put(taskToCache.id(), taskToCache);
            }
        });
        return new SubmitExperimentForTestResult(submitted, assignment);
    }

    private void requireTaskWriteAccess(String taskId, SessionPrincipal principal) {
        if (principal == null || principal.userId() == null || principal.userId().isBlank()
                || principal.role() == null || principal.role().isBlank()) {
            throw new BusinessException("SESSION_PRINCIPAL_REQUIRED", "实验单操作必须使用服务端会话身份");
        }
        if ("RND_DIRECTOR".equals(principal.role())) return;
        if (!"RND_ENGINEER".equals(principal.role())) {
            throw new BusinessException("EXPERIMENT_FORM_TASK_FORBIDDEN", "当前用户无权操作该实验单");
        }
        if (rndTaskRepository == null) {
            var task = tasks.get(taskId);
            if (task == null || !principal.name().equals(task.assigneeName())) {
                throw new BusinessException("EXPERIMENT_FORM_TASK_FORBIDDEN", "当前用户无权操作该实验单");
            }
            return;
        }
        var entity = rndTaskRepository.findById(taskId)
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_TASK_FORBIDDEN", "当前用户无权操作该实验单"));
        var ownerId = entity.getAssigneeUserId();
        if (ownerId == null || ownerId.isBlank()) {
            var matches = userAccountRepository == null ? List.<com.lhr.rnd.persistence.entity.UserAccountEntity>of()
                    : userAccountRepository.findAllByNameAndStatus(entity.getAssigneeName(), "ACTIVE");
            if (matches.size() != 1) throw new BusinessException("EXPERIMENT_FORM_TASK_FORBIDDEN", "当前用户无权操作该实验单");
            ownerId = matches.get(0).getId();
        }
        if (!principal.userId().equals(ownerId)) {
            throw new BusinessException("EXPERIMENT_FORM_TASK_FORBIDDEN", "当前用户无权操作该实验单");
        }
    }

    @Transactional
    public synchronized PassInternalTestResult passInternalTest(String testAssignmentId, String testerName, String comment) {
        return passInternalTest(testAssignmentId, testerName, comment, null);
    }

    @Transactional
    public synchronized PassInternalTestResult passInternalTest(String testAssignmentId, String testerName, String comment,
                                                                SessionPrincipal principal) {
        var assignment = principal == null ? pendingTestAssignment(testAssignmentId, testerName)
                : pendingTestAssignment(testAssignmentId, principal);
        var trustedTesterName = principal == null ? testerName : principal.name();
        var form = requiredExperimentForm(assignment.experimentFormId());
        ensureWorkflowAllows(SampleStatus.PENDING_TEST, SampleAction.TEST_PASS);
        var locked = form.lock();

        var passed = assignment.withStatus(TestAssignmentStatus.PASSED);
        var record = testRecord(passed, trustedTesterName, TestAssignmentStatus.PASSED, comment);

        var task = tasks.get(assignment.taskId());
        if (task == null && rndTaskRepository != null) {
            task = rndTaskRepository.findById(assignment.taskId())
                    .map(this::hydrateRndTask)
                    .orElse(null);
        }
        var completedTask = task == null ? null : task.withStatus(RndTaskStatus.COMPLETED);
        persistPassedInternalTest(locked, passed, record, completedTask);
        var taskToCache = completedTask;
        cacheAfterCommit(() -> {
            experimentForms.put(locked.id(), locked);
            testAssignments.put(passed.id(), passed);
            testRecords.put(record.id(), record);
            if (taskToCache != null) {
                tasks.put(taskToCache.id(), taskToCache);
            }
        });
        if (auditLogService != null && principal != null) {
            auditLogService.record("TEST_ASSIGNMENT", assignment.id(), "PASS", principal.name(), principal.userId(), comment == null ? "" : comment);
        }
        return new PassInternalTestResult(locked, passed, record, completedTask);
    }

    @Transactional
    public synchronized FailInternalTestResult failInternalTestForResample(String testAssignmentId, String testerName, String comment) {
        return failInternalTestForResample(testAssignmentId, testerName, comment, null);
    }

    @Transactional
    public synchronized FailInternalTestResult failInternalTestForResample(String testAssignmentId, String testerName, String comment,
                                                                           SessionPrincipal principal) {
        var assignment = principal == null ? pendingTestAssignment(testAssignmentId, testerName)
                : pendingTestAssignment(testAssignmentId, principal);
        var trustedTesterName = principal == null ? testerName : principal.name();
        ensureWorkflowAllows(SampleStatus.PENDING_TEST, SampleAction.TEST_FAIL_RESAMPLE);
        var locked = requiredExperimentForm(assignment.experimentFormId()).lock();
        var failed = assignment.withStatus(TestAssignmentStatus.FAILED_RESAMPLE);
        var record = testRecord(failed, trustedTesterName, TestAssignmentStatus.FAILED_RESAMPLE, comment);

        var currentVersion = requiredVersion(assignment.versionId());
        var nextNumber = currentVersion.versionNumber() == null ? 1 : currentVersion.versionNumber() + 1;
        var nextCode = SampleVersionCode.fromNumber(nextNumber).code();
        var nextVersion = SampleVersion.builder()
                .id(nextSampleVersionId())
                .projectId(currentVersion.projectId())
                .sampleNo(currentVersion.sampleNo())
                .productName(currentVersion.productName())
                .productType(currentVersion.productType())
                .specification(currentVersion.specification())
                .applicationScenario(currentVersion.applicationScenario())
                .flavorRequirement(currentVersion.flavorRequirement())
                .versionNo(nextCode)
                .versionNumber(nextNumber)
                .versionCode(nextCode)
                .ownerName(currentVersion.ownerName())
                .authorName(currentVersion.authorName())
                .createdAt(now())
                .build();

        var previousTask = requiredTask(assignment.taskId());
        var nextTaskStatus = taskStatusAfter(SampleStatus.RESAMPLING_REQUIRED, SampleAction.CREATE_NEXT_VERSION);
        var nextTask = new RndTask(
                nextRndTaskId(),
                nextVersion.projectId(),
                nextVersion.id(),
                nextVersion.sampleNo(),
                nextVersion.productName(),
                nextVersion.versionCode(),
                nextTaskStatus,
                previousTask == null ? null : previousTask.assigneeName(),
                previousTask == null ? null : previousTask.productOwnerName(),
                previousTask == null ? null : previousTask.dueDate(),
                now(),
                null
        );
        persistFailedInternalTest(locked, failed, record, nextVersion, previousTask, nextTask);
        cacheAfterCommit(() -> {
            experimentForms.put(locked.id(), locked);
            testAssignments.put(failed.id(), failed);
            testRecords.put(record.id(), record);
            versions.put(nextVersion.id(), nextVersion);
            tasks.put(previousTask.id(), previousTask.withStatus(RndTaskStatus.COMPLETED));
            tasks.put(nextTask.id(), nextTask);
        });
        if (auditLogService != null && principal != null) {
            auditLogService.record("TEST_ASSIGNMENT", assignment.id(), "FAIL_RESAMPLE", principal.name(), principal.userId(), comment == null ? "" : comment);
        }
        return new FailInternalTestResult(failed, record, nextVersion, nextTask);
    }

    public synchronized List<SampleRequest> requests() {
        return requests(null, null);
    }

    public synchronized List<SampleRequest> requests(String status, String keyword) {
        var source=sampleRequestRepository == null ? requests.values().stream() : sampleRequestRepository.findAll().stream().map(this::hydrateRequest);
        return source
                .filter(request -> matchesStatus(status, request.status().name()))
                .filter(request -> matchesKeyword(
                        keyword,
                        request.sampleNo(),
                        request.productName(),
                        request.productType(),
                        request.customerName(),
                        request.specification(),
                        request.applicationScenario(),
                        request.flavorRequirement(),
                        request.creatorName(),
                        request.status().name()
                ))
                .toList();
    }

    public synchronized PagedResult<SampleRequest> requests(String status, String keyword, Integer page, Integer size, String sort) {
        return paginate(
                requests(status, keyword),
                page,
                size,
                sort,
                SampleRequest::createdAt
        );
    }

    public synchronized List<RndTask> tasks(String status, String keyword) {
        return tasks(status, keyword, null);
    }

    public synchronized List<RndTask> tasks(String status, String keyword, String assigneeName) {
        restoreTaskCache();
        return tasks.values().stream()
                .filter(task -> matchesStatus(status, task.status().name()))
                .filter(task -> matchesAssignee(assigneeName, task.assigneeName()))
                .filter(task -> matchesKeyword(
                        keyword,
                        task.id(),
                        task.sampleNo(),
                        task.productName(),
                        task.versionCode(),
                        task.assigneeName(),
                        task.status().name()
                ))
                .toList();
    }

    public synchronized PagedResult<RndTask> tasks(String status, String keyword, Integer page, Integer size, String sort) {
        return tasks(status, keyword, null, page, size, sort);
    }

    public synchronized PagedResult<RndTask> tasks(
            String status,
            String keyword,
            String assigneeName,
            Integer page,
            Integer size,
            String sort
    ) {
        return paginate(
                tasks(status, keyword, assigneeName),
                page,
                size,
                sort,
                RndTask::createdAt
        );
    }

    public synchronized boolean hasWorkflowData() {
        if (!tasks.isEmpty()) {
            return true;
        }
        return rndTaskRepository != null && rndTaskRepository.count() > 0;
    }

    public synchronized RndTaskDetailView rndTaskDetail(String taskId, String role, String operatorName) {
        return rndTaskDetailInternal(taskId, role, operatorName, false, null);
    }

    public synchronized RndTaskDetailView rndTaskDetail(String taskId, SessionPrincipal principal) {
        if (principal == null || principal.role() == null || principal.role().isBlank()) {
            throw new BusinessException("SESSION_PRINCIPAL_REQUIRED", "任务详情必须使用服务端会话身份");
        }
        return rndTaskDetailInternal(taskId, principal.role(), principal.name(),
                "TESTER".equals(principal.role()) || "QA_TESTER".equals(principal.role()), principal.userId());
    }

    private RndTaskDetailView rndTaskDetailInternal(String taskId, String role, String operatorName, boolean formalOnly,
                                                    String operatorUserId) {
        var task = requiredTask(taskId);
        var version = requiredVersion(task.versionId());
        var project = SampleProjectSummary.from(projects.get(task.projectId()));
        var currentTestAssignment = currentTestAssignment(taskId);
        if (formalOnly && currentTestAssignment != null && currentTestAssignment.testerUserId() != null
                && !currentTestAssignment.testerUserId().equals(operatorUserId)) {
            throw new BusinessException("TEST_ASSIGNMENT_TESTER_MISMATCH", "只能由被配置的测试人员查看该测试任务");
        }
        var currentExperimentForm = currentExperimentForm(taskId);
        if (formalOnly) currentExperimentForm = formalExperimentFormOrNull(currentExperimentForm, currentTestAssignment);
        return new RndTaskDetailView(
                task,
                version,
                project,
                currentExperimentForm,
                currentTestAssignment,
                detailFieldGroups(task, version, currentExperimentForm, currentTestAssignment),
                detailActions(task, currentExperimentForm, currentTestAssignment, role, operatorName),
                sourceRequestForTask(task)
        );
    }

    private SampleRequest sourceRequestForTask(RndTask task) {
        if(sampleProjectRepository==null||sampleRequestRepository==null)return null;
        return sampleProjectRepository.findById(task.projectId())
                .map(SampleProjectEntity::requestId)
                .flatMap(sampleRequestRepository::findById)
                .map(this::hydrateRequest).orElse(null);
    }

    private ExperimentForm formalExperimentFormOrNull(ExperimentForm draft, TestAssignment assignment) {
        if (draft == null || processRevisionService == null) return null;
        if (assignment == null) return null;
        if (assignment.processRevisionId() == null || assignment.processRevisionId().isBlank()) {
            throw new BusinessException("PROCESS_FORMAL_REVISION_REQUIRED", "该测试任务未绑定正式工艺版本，请研发重新送测");
        }
        var revision = processRevisionService.find(draft.id(), assignment.processRevisionId());
        return new ExperimentForm(draft.id(), draft.taskId(), draft.projectId(), draft.versionId(), draft.sampleNo(),
                draft.productName(), draft.versionCode(), ExperimentFormStatus.SUBMITTED_FOR_TEST, revision.submittedBy(),
                null, List.of(), List.of(), null, null, null, null, null, null,
                java.time.LocalDateTime.parse(revision.submittedAt()));
    }

    public synchronized List<TestRecord> testRecordsForTask(String taskId) {
        var fromMemory = testAssignments.values().stream()
                .filter(assignment -> assignment.taskId().equals(taskId))
                .map(TestAssignment::id)
                .toList();
        if (!fromMemory.isEmpty()) {
            return testRecords.values().stream()
                    .filter(record -> fromMemory.contains(record.testAssignmentId()))
                    .sorted(Comparator.comparing(TestRecord::testedAt).reversed())
                    .toList();
        }
        if (testAssignmentRepository == null || testRecordRepository == null) {
            return List.of();
        }
        var assignmentIds = testAssignmentRepository.findByTaskIdOrderByAssignedAtDesc(taskId).stream()
                .map(TestAssignmentEntity::getId)
                .toList();
        if (assignmentIds.isEmpty()) {
            return List.of();
        }
        return testRecordRepository.findByTestAssignmentIdInOrderByTestedAtDesc(assignmentIds).stream()
                .map(entity -> new TestRecord(
                        entity.getId(), entity.getTestAssignmentId(), entity.getExperimentFormId(), entity.getTesterName(),
                        TestAssignmentStatus.valueOf(entity.getResult()), entity.getComment(), entity.getTestedAt()
                ))
                .toList();
    }

    public synchronized List<PricingFileRecord> pricingFiles(String status, String keyword) {
        return pricingFiles(status, keyword, null, null);
    }

    public synchronized List<PricingFileRecord> pricingFiles(String status, String keyword, String role) {
        return pricingFiles(status, keyword, role, null);
    }

    public synchronized List<PricingFileRecord> pricingFiles(
            String status,
            String keyword,
            String role,
            String operatorName
    ) {
        return allPricingFiles().stream()
                .filter(pricingFile -> !hasRole(role, "FINANCE") || isFinanceVisible(pricingFile))
                .filter(pricingFile -> !hasRole(role, "RND_ENGINEER") || isPricingOwner(pricingFile, operatorName))
                .filter(pricingFile -> matchesStatus(status, pricingFile.status().name()))
                .filter(pricingFile -> matchesKeyword(
                        keyword,
                        pricingFile.id(),
                        pricingFile.sampleNo(),
                        pricingFile.productName(),
                        pricingFile.versionCode(),
                        pricingFile.pricingVersion(),
                        pricingFile.fileName(),
                        pricingFile.status().name()
                ))
                .toList();
    }

    public synchronized List<PricingReadyVersion> pricingReadyVersions() {
        var lockedVersionIds = new LinkedHashSet<String>();
        experimentForms.values().stream()
                .filter(form -> form.status() == ExperimentFormStatus.LOCKED)
                .map(ExperimentForm::versionId)
                .forEach(lockedVersionIds::add);
        if (experimentFormRepository != null) {
            experimentFormRepository.findByStatus(ExperimentFormStatus.LOCKED.name()).stream()
                    .map(ExperimentFormEntity::getVersionId)
                    .forEach(lockedVersionIds::add);
        }

        return lockedVersionIds.stream()
                .filter(this::canGenerateNextPricingVersion)
                .map(this::pricingReadyVersion)
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(PricingReadyVersion::sampleNo).reversed())
                .toList();
    }

    private PricingReadyVersion pricingReadyVersion(String versionId) {
        var version = versions.get(versionId);
        if (version == null && sampleVersionRepository != null) {
            version = sampleVersionRepository.findById(versionId)
                    .map(entity -> SampleVersion.builder()
                            .id(entity.getId())
                            .projectId(entity.getProjectId())
                            .sampleNo(entity.getSampleNo())
                            .productName(entity.getProductName())
                            .productType(entity.getProductType())
                            .specification(entity.getSpecification())
                            .versionNo(entity.getVersionNo())
                            .versionNumber(entity.getVersionNumber())
                            .versionCode(entity.getVersionCode())
                            .createdAt(entity.getCreatedAt())
                            .build())
                    .orElse(null);
        }
        if (version == null) {
            return null;
        }
        var taskId = tasks.values().stream()
                .filter(task -> task.versionId().equals(versionId))
                .map(RndTask::id)
                .findFirst()
                .orElseGet(() -> rndTaskRepository == null ? null : rndTaskRepository.findAll().stream()
                        .filter(task -> task.getVersionId().equals(versionId))
                        .map(RndTaskEntity::getId)
                        .findFirst()
                        .orElse(null));
        return new PricingReadyVersion(
                version.id(),
                taskId,
                version.sampleNo(),
                version.productName(),
                version.versionCode()
        );
    }

    public synchronized PagedResult<PricingFileRecord> pricingFiles(String status, String keyword, Integer page, Integer size, String sort) {
        return pricingFiles(status, keyword, page, size, sort, null);
    }

    public synchronized PagedResult<PricingFileRecord> pricingFiles(
            String status,
            String keyword,
            Integer page,
            Integer size,
            String sort,
            String role
    ) {
        return pricingFiles(status, keyword, page, size, sort, role, null);
    }

    public synchronized PagedResult<PricingFileRecord> pricingFiles(
            String status,
            String keyword,
            Integer page,
            Integer size,
            String sort,
            String role,
            String operatorName
    ) {
        return paginate(
                pricingFiles(status, keyword, role, operatorName),
                page,
                size,
                sort,
                PricingFileRecord::generatedAt
        );
    }

    public synchronized ShipmentDetailView shipmentDetail(String shipmentId, String role) {
        var shipment = requiredShipment(shipmentId);
        var version = requiredVersion(shipment.versionId());
        var feedback = currentCustomerFeedback(shipment.id());
        return new ShipmentDetailView(
                shipment,
                version,
                feedback,
                shipmentFieldGroups(feedback),
                shipmentActions(shipment, role)
        );
    }

    public synchronized PricingFileDetailView pricingFileDetail(String pricingFileId, String role) {
        return pricingFileDetail(pricingFileId, role, null);
    }

    public synchronized PricingFileDetailView pricingFileDetail(
            String pricingFileId,
            String role,
            String operatorName
    ) {
        var pricingFile = requiredPricingFile(pricingFileId);
        if (hasRole(role, "FINANCE") && !isFinanceVisible(pricingFile)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_FINANCE", "财务只能查看已通过审核并通知的核价文件");
        }
        if (hasRole(role, "RND_ENGINEER") && !isPricingOwner(pricingFile, operatorName)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_RND_ENGINEER", "研发人员只能查看本人负责产品的核价文件");
        }
        var version = requiredVersion(pricingFile.versionId());
        var financeNotification = currentFinanceNotification(pricingFile.id());
        return new PricingFileDetailView(
                pricingFile,
                version,
                pricingProcessSource(pricingFile, version),
                financeNotification,
                pricingPackagingItems(pricingFile.id()),
                pricingFileFieldGroups(financeNotification),
                pricingFileActions(pricingFile, role)
        );
    }

    public synchronized DashboardOverview dashboardOverview() {
        var pendingReviewCount = requests.values().stream()
                .filter(request -> request.status() == SampleStatus.PENDING_REVIEW)
                .count();
        var pendingAssignmentCount = tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.PENDING_ASSIGNMENT)
                .count();
        var pendingAcceptanceCount = tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.PENDING_ACCEPTANCE)
                .count();
        var samplingCount = tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.SAMPLING)
                .count();
        var pendingTestCount = tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.PENDING_TEST)
                .count();
        var completedSampleCount = tasks.values().stream()
                .filter(task -> task.status() == RndTaskStatus.COMPLETED)
                .count();
        var pendingPricingCount = allPricingFiles().stream()
                .filter(pricingFile -> pricingFile.status() == PricingFileStatus.PENDING_PRICING_REVIEW)
                .count();
        var financeNotifiedCount = allPricingFiles().stream()
                .filter(pricingFile -> pricingFile.status() == PricingFileStatus.FINANCE_NOTIFIED)
                .count();
        var stoppedCount = projects.values().stream()
                .filter(project -> project.status() == SampleStatus.STOPPED)
                .count();
        var recentTasks = tasks.values().stream()
                .filter(task -> task.status() != RndTaskStatus.COMPLETED)
                .sorted(Comparator.comparing(RndTask::createdAt).reversed())
                .limit(3)
                .map(this::dashboardTaskItem)
                .toList();
        var pendingPricingFiles = allPricingFiles().stream()
                .filter(pricingFile -> pricingFile.status() == PricingFileStatus.PENDING_PRICING_REVIEW)
                .sorted(Comparator.comparing(PricingFileRecord::generatedAt).reversed())
                .limit(5)
                .map(this::dashboardPricingFileItem)
                .toList();

        return new DashboardOverview(
                pendingReviewCount,
                pendingAssignmentCount,
                pendingAcceptanceCount,
                samplingCount,
                pendingTestCount,
                completedSampleCount,
                pendingPricingCount,
                financeNotifiedCount,
                stoppedCount,
                recentTasks,
                pendingPricingFiles
        );
    }

    public synchronized List<StoppedSampleProjectView> stoppedProjects() {
        return projects.values().stream()
                .filter(project -> project.status() == SampleStatus.STOPPED)
                .map(this::stoppedProjectView)
                .toList();
    }

    public synchronized List<ShipmentRecord> shipments(String status, String keyword) {
        return shipments.values().stream()
                .filter(shipment -> matchesStatus(status, shipment.status().name()))
                .filter(shipment -> matchesKeyword(
                        keyword,
                        shipment.sampleNo(),
                        shipment.productName(),
                        shipment.versionCode(),
                        shipment.receiverName(),
                        shipment.trackingNo()
                ))
                .sorted(Comparator.comparing(ShipmentRecord::shippedAt).reversed())
                .toList();
    }

    private DashboardTaskItem dashboardTaskItem(RndTask task) {
        return new DashboardTaskItem(
                task.id(),
                task.sampleNo(),
                task.productName(),
                task.versionCode(),
                task.status().name(),
                task.assigneeName(),
                task.dueDate(),
                task.createdAt()
        );
    }

    private DashboardPricingFileItem dashboardPricingFileItem(PricingFileRecord pricingFile) {
        return new DashboardPricingFileItem(
                pricingFile.id(),
                pricingFile.sampleNo(),
                pricingFile.productName(),
                pricingFile.versionCode(),
                pricingFile.pricingVersion(),
                pricingFile.status().name(),
                pricingFile.generatedAt()
        );
    }

    private boolean matchesStatus(String expectedStatus, String actualStatus) {
        return expectedStatus == null || expectedStatus.isBlank() || expectedStatus.equals(actualStatus);
    }

    private boolean matchesAssignee(String expectedAssigneeName, String actualAssigneeName) {
        if (expectedAssigneeName == null || expectedAssigneeName.isBlank()) {
            return true;
        }
        return expectedAssigneeName.equals(actualAssigneeName);
    }

    private boolean matchesKeyword(String keyword, String... values) {
        if (keyword == null || keyword.isBlank()) {
            return true;
        }
        var normalizedKeyword = keyword.trim().toLowerCase();
        for (String value : values) {
            if (value != null && value.toLowerCase().contains(normalizedKeyword)) {
                return true;
            }
        }
        return false;
    }

    // Single-instance workflow: persisted rows remain reserved after a process restart.
    private String nextAvailableId(String prefix, int start, Map<String, ?> cache,
                                   org.springframework.data.repository.CrudRepository<?, String> repository) {
        for (int candidate = start; ; candidate++) {
            var id = "%s-%04d".formatted(prefix, candidate);
            if (!cache.containsKey(id) && (repository == null || !repository.existsById(id))) return id;
        }
    }

    private String nextExperimentFormId() {
        while (true) {
            var id = "EXP-%04d".formatted(experimentSequence++);
            var existsInDatabase = experimentFormRepository != null && experimentFormRepository.existsById(id);
            if (!experimentForms.containsKey(id) && !existsInDatabase) {
                return id;
            }
        }
    }

    private String nextTestAssignmentId() {
        while (true) {
            var id = "TEST-%04d".formatted(testAssignmentSequence++);
            var existsInDatabase = testAssignmentRepository != null && testAssignmentRepository.existsById(id);
            if (!testAssignments.containsKey(id) && !existsInDatabase) {
                return id;
            }
        }
    }

    private String nextTestRecordId() {
        return "TREC-" + UUID.randomUUID().toString().replace("-", "").substring(0, 27);
    }

    private String nextSampleVersionId() {
        return "VER-" + UUID.randomUUID().toString().replace("-", "").substring(0, 28);
    }

    private String nextRndTaskId() {
        return "TASK-" + UUID.randomUUID().toString().replace("-", "").substring(0, 27);
    }

    private void cacheAfterCommit(Runnable cacheUpdate) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            cacheUpdate.run();
            return;
        }
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                synchronized (SampleWorkflowService.this) {
                    cacheUpdate.run();
                }
            }
        });
    }

    private void cacheWithRollback(Runnable cacheUpdate, Runnable rollbackUpdate) {
        cacheUpdate.run();
        if (!TransactionSynchronizationManager.isSynchronizationActive()) return;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status != STATUS_COMMITTED) {
                    synchronized (SampleWorkflowService.this) {
                        rollbackUpdate.run();
                    }
                }
            }
        });
    }

    private RndTask requiredTask(String taskId) {
        var task = tasks.get(taskId);
        if (task != null) {
            return task;
        }
        if (rndTaskRepository == null) {
            throw new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在");
        }
        return rndTaskRepository.findById(taskId)
                .map(this::hydrateRndTask)
                .map(hydrated -> {
                    tasks.put(hydrated.id(), hydrated);
                    return hydrated;
                })
                .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
    }

    private ShipmentRecord requiredShipment(String shipmentId) {
        var shipment = shipments.get(shipmentId);
        if (shipment == null) {
            throw new BusinessException("SHIPMENT_NOT_FOUND", "寄样记录不存在");
        }
        return shipment;
    }

    public synchronized List<ExperimentProcessStep> processStepsForVersion(String versionId) {
        var form = experimentForms.values().stream()
                .filter(item -> item.versionId().equals(versionId))
                .max(Comparator.comparing(ExperimentForm::savedAt))
                .orElse(null);
        if (form != null) {
            return form.processSteps();
        }
        if (experimentProcessRepository == null || experimentFormRepository == null) {
            return List.of();
        }
        var formEntity = experimentFormRepository.findAll().stream()
                .filter(item -> item.getVersionId().equals(versionId))
                .max(Comparator.comparing(com.lhr.rnd.persistence.entity.ExperimentFormEntity::getSavedAt))
                .orElse(null);
        if (formEntity == null) {
            return List.of();
        }
        return experimentProcessRepository.findByExperimentFormIdOrderBySequenceAsc(formEntity.getId()).stream()
                .map(entity -> new ExperimentProcessStep(
                        entity.getSequence(),
                        entity.getProcessName(),
                        entity.getBeforeWeightKg(),
                        entity.getAfterWeightKg(),
                        entity.getRemainingWeightKg(),
                        entity.getRemainingDisposition(),
                        entity.getLossWeightKg(),
                        entity.getLossRate(),
                        entity.getRemark()
                ))
                .toList();
    }

    public synchronized List<SampleVersionTimelineItem> versionTimeline(String projectId) {
        var projectVersions = versions.values().stream()
                .filter(version -> version.projectId().equals(projectId))
                .sorted(Comparator.comparing(SampleVersion::versionNumber).reversed())
                .toList();
        if (projectVersions.isEmpty() && sampleVersionRepository != null) {
            projectVersions = sampleVersionRepository.findByProjectIdOrderByVersionNumberDesc(projectId).stream()
                    .map(entity -> SampleVersion.builder()
                            .id(entity.getId())
                            .projectId(entity.getProjectId())
                            .sampleNo(entity.getSampleNo())
                            .productName(entity.getProductName())
                            .productType(entity.getProductType())
                            .specification(entity.getSpecification())
                            .versionNo(entity.getVersionNo())
                            .versionNumber(entity.getVersionNumber())
                            .versionCode(entity.getVersionCode())
                            .createdAt(entity.getCreatedAt())
                            .build())
                    .toList();
        }
        return projectVersions.stream()
                .map(version -> {
                    var form = experimentForms.values().stream()
                            .filter(item -> item.versionId().equals(version.id()))
                            .max(Comparator.comparing(ExperimentForm::savedAt))
                            .orElse(null);
                    var task = tasks.values().stream()
                            .filter(item -> item.versionId().equals(version.id()))
                            .findFirst()
                            .orElse(null);
                    var locked = form != null && form.status() == ExperimentFormStatus.LOCKED;
                    var current = task != null && task.status() != RndTaskStatus.COMPLETED;
                    var statusLabel = form == null
                            ? "未开始"
                            : switch (form.status()) {
                                case DRAFT -> "打样中";
                                case SUBMITTED_FOR_TEST -> "待测试";
                                case LOCKED -> "已锁定";
                            };
                    var subtitle = form != null && form.submittedAt() != null
                            ? form.submittedAt().toString()
                            : version.createdAt() != null ? version.createdAt().toString() : "";
                    var summary = form != null ? form.summary() : null;
                    return new SampleVersionTimelineItem(
                            version.id(),
                            version.versionCode(),
                            statusLabel,
                            subtitle,
                            summary,
                            locked,
                            current
                    );
                })
                .toList();
    }

    public synchronized SampleRequest requestDetail(String requestId) {
        var request = sampleRequestRepository == null ? requests.get(requestId)
                : sampleRequestRepository.findById(requestId).map(this::hydrateRequest).orElse(null);
        if (request == null) {
            throw new BusinessException("SAMPLE_REQUEST_NOT_FOUND", "样品需求不存在");
        }
        return request;
    }

    @Transactional
    public synchronized SampleRequest reviseRequest(String id,CreateSampleRequestCommand command,SampleStatus status) {
        var old=requestDetail(id);
        var c=command;
        var next=c==null ? new SampleRequest(old.id(),old.sampleNo(),old.productName(),old.productType(),old.customerName(),old.specification(),
                old.applicationScenario(),old.flavorRequirement(),old.creatorName(),status,old.createdAt(),old.referenceSampleProvided(),old.cutShape(),old.mainMaterialRequirement(),
                old.textureRequirement(),old.packagingRequirement(),old.storageRequirement(),old.customerTargetPrice(),old.monthlyDemand(),old.specialRequirements(),old.referenceMarketPrice(),old.additionalNotes())
                : new SampleRequest(old.id(),old.sampleNo(),c.productName(),c.productType(),c.customerName(),c.specification(),c.applicationScenario(),c.flavorRequirement(),
                c.creatorName(),status,old.createdAt(),c.referenceSampleProvided(),c.cutShape(),c.mainMaterialRequirement(),c.textureRequirement(),c.packagingRequirement(),
                c.storageRequirement(),c.customerTargetPrice(),c.monthlyDemand(),c.specialRequirements(),c.referenceMarketPrice(),c.additionalNotes());
        persistRequest(next);
        requests.put(id,next);
        return next;
    }

    private SampleRequest hydrateRequest(SampleRequestEntity entity) {
        return new SampleRequest(entity.id(), entity.sampleNo(), entity.productName(), entity.productType(),
                entity.customerName(), entity.specification(), entity.applicationScenario(), entity.flavorRequirement(),
                entity.creatorName(), SampleStatus.valueOf(entity.status()), entity.createdAt(), entity.referenceSampleProvided(), entity.cutShape(), entity.mainMaterialRequirement(), entity.textureRequirement(), entity.packagingRequirement(), entity.storageRequirement(), entity.customerTargetPrice(), entity.monthlyDemand(), entity.specialRequirements(), entity.referenceMarketPrice(), entity.additionalNotes());
    }

    private void restoreTaskCache() {
        if (rndTaskRepository != null) rndTaskRepository.findAll().stream().map(this::hydrateRndTask)
                .forEach(value -> tasks.putIfAbsent(value.id(), value));
    }

    private PricingFileRecord requiredPricingFile(String pricingFileId) {
        var pricingFile = pricingFiles.get(pricingFileId);
        if (pricingFile == null && pricingFileRepository != null) {
            pricingFile = pricingFileRepository.findById(pricingFileId)
                    .map(this::toPricingFileRecord)
                    .orElse(null);
            if (pricingFile != null) {
                pricingFiles.put(pricingFile.id(), pricingFile);
            }
        }
        if (pricingFile == null) {
            throw new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在");
        }
        return pricingFile;
    }

    private ExperimentForm currentExperimentForm(String taskId) {
        var cached = experimentForms.values().stream()
                .filter(form -> form.taskId().equals(taskId))
                .max(Comparator.comparing(ExperimentForm::savedAt))
                .orElse(null);
        if (cached != null || experimentFormRepository == null) {
            return cached;
        }
        return experimentFormRepository.findFirstByTaskIdOrderBySavedAtDesc(taskId)
                .map(this::hydrateExperimentForm)
                .map(form -> {
                    experimentForms.put(form.id(), form);
                    return form;
                })
                .orElse(null);
    }

    private ExperimentForm currentExperimentForm(String taskId, String versionId) {
        var cached = experimentForms.values().stream()
                .filter(form -> form.taskId().equals(taskId) && form.versionId().equals(versionId))
                .max(Comparator.comparing(ExperimentForm::savedAt))
                .orElse(null);
        if (cached != null || experimentFormRepository == null) {
            return cached;
        }
        return experimentFormRepository.findFirstByTaskIdAndVersionIdOrderBySavedAtDesc(taskId, versionId)
                .map(this::hydrateExperimentForm)
                .map(form -> {
                    experimentForms.put(form.id(), form);
                    return form;
                })
                .orElse(null);
    }

    private ExperimentForm requiredExperimentForm(String experimentFormId) {
        var cached = experimentForms.get(experimentFormId);
        if (cached != null) {
            return cached;
        }
        if (experimentFormRepository == null) {
            throw new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在");
        }
        return experimentFormRepository.findById(experimentFormId)
                .map(this::hydrateExperimentForm)
                .map(form -> {
                    experimentForms.put(form.id(), form);
                    return form;
                })
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
    }

    private RndTask hydrateRndTask(RndTaskEntity entity) {
        return new RndTask(
                entity.getId(),
                entity.getProjectId(),
                entity.getVersionId(),
                entity.getSampleNo(),
                entity.getProductName(),
                entity.getVersionCode(),
                RndTaskStatus.valueOf(entity.getStatus()),
                entity.getAssigneeName(),
                normalizeProductOwnerName(entity.getProductOwnerName(), entity.getAssigneeName()),
                entity.getDueDate(),
                entity.getCreatedAt(),
                entity.getAcceptedAt() == null ? entity.getAssignedAt() : entity.getAcceptedAt()
        );
    }

    private ExperimentForm hydrateExperimentForm(ExperimentFormEntity entity) {
        var materials = experimentMaterialRepository == null
                ? List.<ExperimentMaterial>of()
                : experimentMaterialRepository.findByExperimentFormIdOrderBySequenceAsc(entity.getId()).stream()
                .map(material -> new ExperimentMaterial(
                        material.getStage(),
                        material.getSequence(),
                        material.getMaterialCode(),
                        material.getMaterialName(),
                        material.getWeightKg(),
                        material.getUtilizationRate() == null ? BigDecimal.ONE : material.getUtilizationRate(),
                        material.getRemark(),
                        material.getMaterialCategory() == null
                                ? categoryFromStage(material.getStage())
                                : material.getMaterialCategory(),
                        Boolean.TRUE.equals(material.getPrimaryMaterial()),
                        material.getFormulaRatio(),
                        material.getInputUnit() == null ? "kg" : material.getInputUnit(),
                        material.getCatalogMaterialId(), material.getCatalogSpecification(), material.getCatalogUnit(), false, material.getId()
                ))
                .toList();
        var processSteps = experimentProcessRepository == null
                ? List.<ExperimentProcessStep>of()
                : experimentProcessRepository.findByExperimentFormIdOrderBySequenceAsc(entity.getId()).stream()
                .map(process -> new ExperimentProcessStep(
                        process.getSequence(),
                        process.getProcessName(),
                        process.getBeforeWeightKg(),
                        process.getAfterWeightKg(),
                        process.getRemainingWeightKg(),
                        process.getRemainingDisposition(),
                        process.getLossWeightKg(),
                        process.getLossRate(),
                        process.getRemark()
                ))
                .toList();
        return new ExperimentForm(
                entity.getId(),
                entity.getTaskId(),
                entity.getProjectId(),
                entity.getVersionId(),
                entity.getSampleNo(),
                entity.getProductName(),
                entity.getVersionCode(),
                ExperimentFormStatus.valueOf(entity.getStatus()),
                entity.getOperatorName(),
                entity.getSummary(),
                materials,
                processSteps,
                entity.getFinishedOutputWeightKg(),
                entity.getFinishedOutputQuantity(),
                normalizeFinishedOutputUnit(entity.getFinishedOutputUnit()),
                entity.getYieldCalculationMode() == null
                        ? YieldCalculationMode.SELECTED_PRIMARY_MATERIALS
                        : YieldCalculationMode.valueOf(entity.getYieldCalculationMode()),
                entity.getFinishedYieldPercent(),
                entity.getSavedAt(),
                entity.getSubmittedAt()
        );
    }

    private TestAssignment currentTestAssignment(String taskId) {
        var cached = testAssignments.values().stream()
                .filter(assignment -> assignment.taskId().equals(taskId))
                .max(Comparator.comparing(TestAssignment::assignedAt))
                .orElse(null);
        if (cached != null || testAssignmentRepository == null) return cached;
        return testAssignmentRepository.findFirstByTaskIdAndArchivedAtIsNullOrderByAssignedAtDesc(taskId)
                .map(this::hydrateTestAssignment)
                .map(persisted -> {
                    testAssignments.put(persisted.id(), persisted);
                    return persisted;
                }).orElse(null);
    }

    private CustomerFeedback currentCustomerFeedback(String shipmentId) {
        return customerFeedbacks.values().stream()
                .filter(feedback -> feedback.shipmentId().equals(shipmentId))
                .max(Comparator.comparing(CustomerFeedback::feedbackAt))
                .orElse(null);
    }

    private FinanceNotification currentFinanceNotification(String pricingFileId) {
        return financeNotifications.values().stream()
                .filter(notification -> notification.pricingFileId().equals(pricingFileId))
                .max(Comparator.comparing(FinanceNotification::notifiedAt))
                .orElseGet(() -> financeNotificationRepository == null ? null : financeNotificationRepository
                        .findFirstByPricingFileIdOrderByNotifiedAtDesc(pricingFileId)
                        .map(this::toFinanceNotification)
                        .orElse(null));
    }

    private List<DetailFieldGroup> detailFieldGroups(
            RndTask task,
            SampleVersion version,
            ExperimentForm currentExperimentForm,
            TestAssignment currentTestAssignment
    ) {
        var groups = new ArrayList<DetailFieldGroup>();
        groups.add(new DetailFieldGroup("基础信息", List.of(
                "sampleNo",
                "productName",
                "productType",
                "customerName",
                "specification",
                "versionCode",
                "applicationScenario",
                "flavorRequirement"
        )));
        groups.add(new DetailFieldGroup("任务信息", List.of(
                "status",
                "assigneeName",
                "dueDate",
                "createdAt",
                "assignedAt"
        )));
        if (currentExperimentForm != null) {
            groups.add(new DetailFieldGroup("实验单", List.of(
                    "currentExperimentForm.id",
                    "currentExperimentForm.status",
                    "currentExperimentForm.operatorName",
                    "currentExperimentForm.summary",
                    "currentExperimentForm.materials"
            )));
        }
        if (currentTestAssignment != null) {
            groups.add(new DetailFieldGroup("内部测试", List.of(
                    "currentTestAssignment.id",
                    "currentTestAssignment.testerName",
                    "currentTestAssignment.status",
                    "currentTestAssignment.assignedAt"
            )));
        }
        return groups;
    }

    private List<DetailAction> detailActions(
            RndTask task,
            ExperimentForm currentExperimentForm,
            TestAssignment currentTestAssignment,
            String role,
            String operatorName
    ) {
        if (role == null || role.isBlank()) {
            return List.of();
        }
        return switch (task.status()) {
            case PENDING_ASSIGNMENT -> hasRole(role, "RND_DIRECTOR")
                    ? List.of(action("ASSIGN_TASK", "分发任务", "POST", "/api/v1/rnd-tasks/" + task.id() + "/assign", true))
                    : List.of();
            case PENDING_ACCEPTANCE -> canEngineerOperate(task, role, operatorName)
                    ? List.of(action("ACCEPT_TASK", "接受任务", "POST", "/api/v1/rnd-tasks/" + task.id() + "/accept", true))
                    : List.of();
            case SAMPLING -> samplingActions(task, currentExperimentForm, role, operatorName);
            case PENDING_TEST -> testActions(currentTestAssignment, role, operatorName);
            case COMPLETED -> completedActions(task, role);
        };
    }

    private boolean canEngineerOperate(RndTask task, String role, String operatorName) {
        if (hasRole(role, "RND_DIRECTOR")) return true;
        if (!hasRole(role, "RND_ENGINEER")) return false;
        if (operatorName == null || operatorName.isBlank()) {
            return true;
        }
        return operatorName.equals(task.assigneeName());
    }

    private List<DetailAction> samplingActions(
            RndTask task,
            ExperimentForm currentExperimentForm,
            String role,
            String operatorName
    ) {
        var actions = new ArrayList<DetailAction>();
        if (canEngineerOperate(task, role, operatorName)) {
            actions.add(action(
                    "OPEN_EXPERIMENT_FORM",
                    currentExperimentForm == null ? "开始填写打样实验单" : "继续填写打样实验单",
                    "GET",
                    "/rnd/tasks/" + task.id() + "/experiment",
                    true
            ));
        }
        if (currentExperimentForm != null && currentExperimentForm.status() == ExperimentFormStatus.DRAFT
                && canEngineerOperate(task, role, operatorName)) {
            actions.add(action(
                    "SUBMIT_EXPERIMENT_TEST",
                    "提交内部测试",
                    "POST",
                    "/api/v1/experiment-forms/" + currentExperimentForm.id() + "/submit-test",
                    true
            ));
        }
        return actions;
    }

    private List<DetailAction> testActions(TestAssignment currentTestAssignment, String role, String operatorName) {
        if (!hasRole(role, "TESTER", "QA_TESTER") || currentTestAssignment == null
                || currentTestAssignment.status() != TestAssignmentStatus.PENDING_TEST) {
            return List.of();
        }
        if (operatorName != null && !operatorName.isBlank()
                && !operatorName.equals(currentTestAssignment.testerName())) {
            return List.of();
        }
        return List.of(
                action("PASS_INTERNAL_TEST", "测试通过并锁版", "POST", "/api/v1/test-assignments/" + currentTestAssignment.id() + "/pass", true),
                action("FAIL_RESAMPLE", "不通过复打样", "POST", "/api/v1/test-assignments/" + currentTestAssignment.id() + "/fail-resample", false)
        );
    }

    private List<DetailAction> completedActions(RndTask task, String role) {
        if (!hasRole(role, "RND_ASSISTANT")) {
            return List.of();
        }
        return List.of(
                action("CREATE_SHIPMENT", "登记寄样", "POST", "/api/v1/sample-versions/" + task.versionId() + "/shipments", true),
                action("GENERATE_PRICING_FILE", "生成核价文件", "POST", "/api/v1/sample-versions/" + task.versionId() + "/pricing-files", false)
        );
    }

    private List<DetailFieldGroup> shipmentFieldGroups(CustomerFeedback feedback) {
        var groups = new ArrayList<DetailFieldGroup>();
        groups.add(new DetailFieldGroup("寄样信息", List.of(
                "shipment.id",
                "shipment.sampleNo",
                "shipment.productName",
                "shipment.versionCode",
                "shipment.quantity",
                "shipment.receiverName",
                "shipment.trackingNo",
                "shipment.status",
                "shipment.shippedAt"
        )));
        if (feedback != null) {
            groups.add(new DetailFieldGroup("客户反馈", List.of(
                    "customerFeedback.feedbackBy",
                    "customerFeedback.result",
                    "customerFeedback.comment",
                    "customerFeedback.feedbackAt"
            )));
        }
        return groups;
    }

    private List<DetailFieldGroup> pricingFileFieldGroups(FinanceNotification financeNotification) {
        var groups = new ArrayList<DetailFieldGroup>();
        groups.add(new DetailFieldGroup("核价文件", List.of(
                "pricingFile.id",
                "pricingFile.sampleNo",
                "pricingFile.productName",
                "pricingFile.versionCode",
                "pricingFile.pricingVersion",
                "pricingFile.fileName",
                "pricingFile.status",
                "pricingFile.generatedAt",
                "pricingFile.reviewedBy",
                "pricingFile.reviewedAt",
                "pricingFile.reviewComment",
                "pricingFile.rejectionReason"
        )));
        if (financeNotification != null) {
            groups.add(new DetailFieldGroup("财务通知", List.of(
                    "financeNotification.recipientName",
                    "financeNotification.remark",
                    "financeNotification.status",
                    "financeNotification.notifiedAt"
            )));
        }
        return groups;
    }

    private List<DetailAction> shipmentActions(ShipmentRecord shipment, String role) {
        if (!hasRole(role, "RND_ASSISTANT")) {
            return List.of();
        }
        if (shipment.status() == ShipmentStatus.SHIPPED) {
            return List.of(
                    action("CUSTOMER_FEEDBACK_PASS", "客户通过", "POST", "/api/v1/shipments/" + shipment.id() + "/feedback", true),
                    action("CUSTOMER_FEEDBACK_RESAMPLE", "客户不通过复打样", "POST", "/api/v1/shipments/" + shipment.id() + "/feedback", false),
                    action("CUSTOMER_FEEDBACK_STOP", "停止打样", "POST", "/api/v1/shipments/" + shipment.id() + "/feedback", false)
            );
        }
        if (shipment.status() == ShipmentStatus.FEEDBACK_PASSED) {
            return List.of(action(
                    "GENERATE_PRICING_FILE",
                    "生成核价文件",
                    "POST",
                    "/api/v1/sample-versions/" + shipment.versionId() + "/pricing-files",
                    true
            ));
        }
        return List.of();
    }

    private List<DetailAction> pricingFileActions(PricingFileRecord pricingFile, String role) {
        if (!hasRole(role, "RND_ASSISTANT", "RND_DIRECTOR", "RND_ENGINEER", "FINANCE")) {
            return List.of();
        }
        var actions = new ArrayList<DetailAction>();
        if (pricingFile.status() != PricingFileStatus.DRAFT_PACKAGING) {
            actions.add(action(
                    "DOWNLOAD_PRICING_FILE",
                    "下载核价文件",
                    "GET",
                    "/api/v1/pricing-files/" + pricingFile.id() + "/download",
                    true
            ));
        }
        if (hasRole(role, "RND_DIRECTOR", "RND_ENGINEER")
                && pricingFile.status() == PricingFileStatus.DRAFT_PACKAGING) {
            actions.add(action(
                    "CONFIRM_PRICING_PACKAGING",
                    "确认包装并生成核价文件",
                    "PUT",
                    "/api/v1/pricing-files/" + pricingFile.id() + "/packaging-items",
                    true
            ));
        }
        if (hasRole(role, "RND_DIRECTOR", "RND_ENGINEER")
                && pricingFile.status() == PricingFileStatus.PENDING_PRICING_REVIEW) {
            actions.add(action(
                    "REVIEW_PRICING_FILE",
                    "审核核价文件",
                    "POST",
                    "/api/v1/pricing-files/" + pricingFile.id() + "/review",
                    true
            ));
        }
        return actions;
    }

    private DetailAction action(String code, String label, String httpMethod, String endpoint, boolean primary) {
        return new DetailAction(code, label, httpMethod, endpoint, primary);
    }

    private boolean hasRole(String role, String... allowedRoles) {
        for (String allowedRole : allowedRoles) {
            if (allowedRole.equals(role)) {
                return true;
            }
        }
        return false;
    }

    private <T> PagedResult<T> paginate(
            List<T> source,
            Integer page,
            Integer size,
            String sort,
            Function<T, LocalDateTime> timeExtractor
    ) {
        var resolvedPage = page == null || page < 0 ? 0 : page;
        var resolvedSize = size == null || size <= 0 ? 20 : Math.min(size, 200);
        var descending = sort == null || sort.isBlank() || !sort.toLowerCase().endsWith(",asc");
        Comparator<T> comparator = Comparator.comparing(timeExtractor);
        if (descending) {
            comparator = comparator.reversed();
        }
        var sorted = source.stream()
                .sorted(comparator)
                .toList();
        var total = sorted.size();
        var fromIndex = Math.min(resolvedPage * resolvedSize, total);
        var toIndex = Math.min(fromIndex + resolvedSize, total);
        var totalPages = total == 0 ? 0 : (int) Math.ceil((double) total / resolvedSize);
        return new PagedResult<>(
                sorted.subList(fromIndex, toIndex),
                total,
                resolvedPage,
                resolvedSize,
                totalPages
        );
    }

    @Transactional
    public synchronized ShipmentRecord createShipment(CreateShipmentCommand command) {
        var version = requiredVersion(command.versionId());
        ensureReadyForShipment(command.versionId());
        var shipment = new ShipmentRecord(
                nextAvailableId("SHIP", shipmentSequence++, shipments, shipmentRecordRepository),
                version.id(),
                version.sampleNo(),
                version.productName(),
                version.versionCode(),
                command.quantity(),
                command.receiverName(),
                command.trackingNo(),
                command.remark(),
                ShipmentStatus.SHIPPED,
                now()
        );
        shipments.put(shipment.id(), shipment);
        persistShipment(shipment);
        return shipment;
    }

    @Transactional
    public synchronized ShipmentFeedbackResult submitCustomerFeedback(SubmitCustomerFeedbackCommand command) {
        var shipment = shipments.get(command.shipmentId());
        if (shipment == null) {
            throw new BusinessException("SHIPMENT_NOT_FOUND", "寄样记录不存在");
        }
        if (shipment.status() != ShipmentStatus.SHIPPED) {
            throw new BusinessException("SHIPMENT_STATUS_ILLEGAL", "当前寄样状态不可反馈");
        }
        ensureWorkflowAllows(SampleStatus.SAMPLE_COMPLETED, customerFeedbackAction(command.result()));

        var nextStatus = switch (command.result()) {
            case PASSED -> ShipmentStatus.FEEDBACK_PASSED;
            case FAILED_RESAMPLE -> ShipmentStatus.FEEDBACK_FAILED_RESAMPLE;
            case STOPPED -> ShipmentStatus.STOPPED;
        };
        var updatedShipment = shipment.withStatus(nextStatus);
        shipments.put(updatedShipment.id(), updatedShipment);

        var feedback = new CustomerFeedback(
                nextAvailableId("CFB", customerFeedbackSequence++, customerFeedbacks, customerFeedbackRepository),
                shipment.id(),
                command.feedbackBy(),
                command.result(),
                command.comment(),
                now()
        );
        customerFeedbacks.put(feedback.id(), feedback);
        var resamplePreviousTask = taskByVersionId(shipment.versionId());
        var resampleTask = command.result() == CustomerFeedbackResult.FAILED_RESAMPLE
                ? createCustomerResampleTask(shipment.versionId())
                : null;
        var stoppedProject = command.result() == CustomerFeedbackResult.STOPPED
                ? updateProjectStatusForVersion(shipment.versionId(), SampleStatus.STOPPED)
                : null;
        persistCustomerFeedback(updatedShipment, feedback);
        if (resampleTask != null) {
            persistCustomerResampleTask(resampleTask.nextVersion(), resamplePreviousTask, resampleTask.nextTask());
        }
        if (stoppedProject != null) {
            persistSampleProjectStatus(stoppedProject);
        }
        return new ShipmentFeedbackResult(updatedShipment, feedback);
    }

    @Transactional
    public synchronized PricingFileRecord generatePricingFile(String versionId) {
        var version = requiredVersion(versionId);
        var lockedForm = lockedExperimentForm(versionId);
        if (!canGenerateNextPricingVersion(versionId)) {
            throw new BusinessException("PRICING_FILE_REVIEW_IN_PROGRESS", "当前核价文件待审核或已通过，不能生成新版本");
        }
        ensureWorkflowAllows(SampleStatus.SAMPLE_COMPLETED, SampleAction.REQUEST_PRICING);
        ensurePricingArchiveAllowed();
        var pricingVersionNo = "V" + nextPricingVersionNumber(versionId);
        var referenceOutputKg = resolvePricingReferenceOutput(version, lockedForm);
        var unitWeightKg = resolvePricingUnitWeight(version, lockedForm, referenceOutputKg);
        var versionWithMaterials = SampleVersion.builder()
                .id(version.id())
                .projectId(version.projectId())
                .sampleNo(version.sampleNo())
                .productName(version.productName())
                .productType(version.productType())
                .specification(version.specification())
                .applicationScenario(version.applicationScenario())
                .flavorRequirement(version.flavorRequirement())
                .versionNo(version.versionNo())
                .versionNumber(version.versionNumber())
                .versionCode(version.versionCode())
                .ownerName(version.ownerName())
                .authorName(lockedForm.operatorName())
                .effectiveDate(version.effectiveDate())
                .referenceOutputKg(referenceOutputKg)
                .unitWeightKg(unitWeightKg)
                .materials(lockedForm.materials())
                .createdAt(version.createdAt())
                .build();
        var customerName = projects.containsKey(version.projectId())
                ? projects.get(version.projectId()).customerName()
                : "LHYC";
        var record = new PricingFileRecord(
                nextAvailableId("PRICE", pricingFileSequence++, pricingFiles, pricingFileRepository),
                version.id(),
                version.sampleNo(),
                version.productName(),
                version.versionCode(),
                version.versionNo() + "-核价" + pricingVersionNo,
                version.productName() + "（核价）" + version.versionNo() + "-待确认.xlsx",
                PricingFileStatus.DRAFT_PACKAGING,
                0,
                now()
        );
        pricingFiles.put(record.id(), record);
        persistPricingDraft(record);
        var suggestedItems = pricingPackagingService.createSuggestedItems(
                record.id(),
                versionWithMaterials.productName(),
                referenceOutputKg,
                unitWeightKg,
                bagsPerBox(versionWithMaterials.specification()),
                packagingTemplateItems("DEFAULT_BAG")
        );
        var formalPackagingRevision=latestFormalPricingRevision(lockedForm);
        if(formalPackagingRevision!=null) {
            var actual=new ProcessExportCheckService().view(version.productName(),"正式工艺",formalPackagingRevision.snapshot(),null,List.of()).packaging();
            if(!actual.isEmpty())suggestedItems=actual.stream().map(p->new PricingPackagingItem(java.util.UUID.randomUUID().toString().replace("-",""),record.id(),p.sequence(),com.lhr.rnd.model.PricingPackagingSource.MANUAL,p.materialCode(),p.materialName(),p.quantity(),p.packageSpec(),p.conversionRule(),p.remark(),com.lhr.rnd.model.PricingPackagingStatus.PENDING_CONFIRMATION,null,p.quantityUnit())).toList();
        }
        persistPricingPackagingItems(record.id(), suggestedItems);
        return record;
    }

    @Transactional
    public PricingFileRecord confirmPricingPackaging(
            String pricingFileId,
            List<PricingPackagingItem> requestedItems,
            String operatorName,
            String operatorRole
    ) {
        var archiveReservation = reservePricingArchiveAttempt(pricingFileId);
        var archiveMetadataReady = new boolean[]{false};
        registerPricingArchiveCompletion(archiveReservation, archiveMetadataReady);
        var pricingFile = lockedPricingFile(pricingFileId);
        ensurePricingReviewer(pricingFile, operatorName, operatorRole);
        if (pricingFile.status() != PricingFileStatus.DRAFT_PACKAGING) {
            throw new BusinessException("PRICING_PACKAGING_CONFIRM_ILLEGAL", "当前核价文件不处于包装确认状态");
        }
        var basis = pricingBasisService == null ? null : pricingBasisService.confirmed(pricingFileId, pricingBasisSource(pricingFileId));
        if (basis != null) {
            var expected=basisPackaging(pricingFileId,basis);
            if(requestedItems==null || requestedItems.size()!=expected.size()) throw new BusinessException("PRICING_BASIS_PACKAGING_CHANGED","包装已变化，请重新保存并确认核价数据");
            for(int i=0;i<expected.size();i++) {
                var a=expected.get(i);var b=requestedItems.get(i);
                if(b==null || a.quantity().compareTo(b.quantity()==null?BigDecimal.ZERO:b.quantity())!=0 || !Objects.equals(a.materialName(),b.materialName()) || !Objects.equals(a.quantityUnit(),b.quantityUnit()) || !Objects.equals(a.materialCode(),b.materialCode()) || !Objects.equals(a.packageSpec(),b.packageSpec()) || !Objects.equals(a.remark(),b.remark()))
                    throw new BusinessException("PRICING_BASIS_PACKAGING_CHANGED","包装已变化，请重新保存并确认核价数据");
            }
        }
        var confirmedItems = normalizeConfirmedPackagingItems(pricingFileId, requestedItems);
        pricingPackagingService.validateForSubmission(confirmedItems);
        persistPricingPackagingItems(pricingFileId, confirmedItems);

        var version = requiredVersion(pricingFile.versionId());
        var lockedForm = lockedExperimentForm(pricingFile.versionId());
        var referenceOutputKg = resolvePricingReferenceOutput(version, lockedForm);
        var unitWeightKg = resolvePricingUnitWeight(version, lockedForm, referenceOutputKg);
        var versionWithMaterials = pricingVersionWithLockedExperiment(version, lockedForm, referenceOutputKg, unitWeightKg);
        var customerName = projects.containsKey(version.projectId())
                ? projects.get(version.projectId()).customerName()
                : "LHYC";
        var revision = basis != null && !basis.sourceRevisionId().startsWith("legacy:") ? processRevisionService.find(lockedForm.id(), basis.sourceRevisionId()) : latestFormalPricingRevision(lockedForm);
        if (basis != null && revision != null) {
            var checks=new ProcessExportCheckService();
            checks.requireReady(checks.view(version.productName(),"正式工艺",revision.snapshot(),new com.lhr.rnd.model.ProcessExportView.FinishedQuantity(lockedForm.finishedOutputWeightKg(),lockedForm.finishedOutputQuantity(),lockedForm.finishedOutputUnit(),"独立实测"),confirmedItems),"PRICING_XLSX");
        }
        var generated = basis != null ? new PricingFileResult(version.productName()+"（核价）原材料清单-"+pricingFile.pricingVersion()+".xlsx",pricingFile.pricingVersion(),new PricingMaterialListRenderer().render(basis,new PricingBasisCalculator().calculate(basis),false)) : revision == null
                ? pricingFileService.generate(
                        versionWithMaterials,
                        pricingFile.pricingVersion().replace(version.versionNo() + "-核价", ""),
                        customerName,
                        lockedForm.yieldCalculationMode(),
                        confirmedItems)
                : pricingFileService.generate(
                        versionWithMaterials,
                        pricingFile.pricingVersion().replace(version.versionNo() + "-核价", ""),
                        customerName,
                        revision,
                        confirmedItems,
                        new com.lhr.rnd.model.ProcessExportView.FinishedQuantity(lockedForm.finishedOutputWeightKg(),
                                lockedForm.finishedOutputQuantity(), lockedForm.finishedOutputUnit(), "已锁定实验单独立实测"),
                        trialPromotionService == null ? null : trialPromotionService.sourceForLockedPricing(lockedForm, revision));
        var signature = basis != null && basis.signature() != null ? basis.signature() : com.lhr.rnd.model.DocumentSignature.pending(operatorName, now().toString());
        var signedContent = WorkbookSignatureWriter.stamp(generated.content(),signature);
        var generatedRecord = pricingFile.generated(generated.fileName(), signedContent.length);
        if (revision != null) {
            generatedRecord = generatedRecord.withProcessRevision(revision.id());
        }
        persistGeneratedPricingFile(generatedRecord, signedContent, archiveReservation);
        if(pricingFileRepository != null) {
            var entity=pricingFileRepository.findById(pricingFileId).orElseThrow();
            entity.bindCompiler(signature.compiledBy(),signature.compiledAt()==null?null:LocalDateTime.parse(signature.compiledAt()));
            pricingFileRepository.save(entity);
        }
        archiveMetadataReady[0] = true;
        if (auditLogService != null) {
            auditLogService.record("PRICING_FILE", pricingFileId, "PACKAGING_CONFIRMED", operatorName,
                    "items=" + confirmedItems.size());
        }
        var completedRecord = generatedRecord;
        cacheAfterCommit(() -> pricingFiles.put(completedRecord.id(), completedRecord));
        return completedRecord;
    }

    public synchronized List<PricingPackagingItem> pricingPackagingItems(String pricingFileId) {
        if (pricingPackagingItemRepository == null) {
            return List.of();
        }
        return pricingPackagingItemRepository.findByPricingFileIdOrderBySequenceAsc(pricingFileId).stream()
                .map(this::toPricingPackagingItem)
                .toList();
    }

    private SampleVersion pricingVersionWithLockedExperiment(
            SampleVersion version,
            ExperimentForm lockedForm,
            BigDecimal referenceOutputKg,
            BigDecimal unitWeightKg
    ) {
        return SampleVersion.builder()
                .id(version.id()).projectId(version.projectId()).sampleNo(version.sampleNo())
                .productName(version.productName()).productType(version.productType())
                .specification(version.specification()).applicationScenario(version.applicationScenario())
                .flavorRequirement(version.flavorRequirement()).versionNo(version.versionNo())
                .versionNumber(version.versionNumber()).versionCode(version.versionCode())
                .ownerName(version.ownerName()).authorName(lockedForm.operatorName())
                .effectiveDate(version.effectiveDate()).referenceOutputKg(referenceOutputKg)
                .unitWeightKg(unitWeightKg).materials(lockedForm.materials()).createdAt(version.createdAt())
                .build();
    }

    private List<PricingPackagingItem> normalizeConfirmedPackagingItems(
            String pricingFileId,
            List<PricingPackagingItem> requestedItems
    ) {
        if (requestedItems == null || requestedItems.isEmpty()) {
            return List.of();
        }
        var normalized = new ArrayList<PricingPackagingItem>();
        for (int index = 0; index < requestedItems.size(); index++) {
            var item = requestedItems.get(index);
            normalized.add(new PricingPackagingItem(
                    item.id() == null || item.id().isBlank()
                            ? "PKG-" + UUID.randomUUID().toString().replace("-", "").substring(0, 28)
                            : item.id(),
                    pricingFileId,
                    index + 1,
                    item.source() == null ? PricingPackagingSource.MANUAL : item.source(),
                    blankToNull(item.materialCode()),
                    item.materialName(),
                    item.quantity(),
                    item.packageSpec(),
                    item.conversionRule(),
                    item.remark(),
                    PricingPackagingStatus.CONFIRMED,
                    blankToNull(item.modificationReason()),
                    blankToNull(item.quantityUnit())
            ));
        }
        return normalized;
    }

    private List<PackagingTemplateItem> packagingTemplateItems(String templateCode) {
        if (packagingTemplateItemRepository == null) {
            return List.of();
        }
        return packagingTemplateItemRepository.findByTemplateCodeAndEnabledTrueOrderBySequenceAsc(templateCode).stream()
                .map(this::toPackagingTemplateItem)
                .toList();
    }

    private int bagsPerBox(String specification) {
        if (specification == null) {
            return 1;
        }
        var matcher = java.util.regex.Pattern.compile("(\\d+)袋/箱").matcher(specification);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : 1;
    }

    /**
     * 核价以版本上人工确认的参考值为准；未维护时，直接复用已锁定实验单的实际出成，避免研发重复填写。
     */
    private BigDecimal resolvePricingReferenceOutput(SampleVersion version, ExperimentForm lockedForm) {
        return version.referenceOutputKg() != null
                ? version.referenceOutputKg()
                : lockedForm.finishedOutputWeightKg();
    }

    private BigDecimal resolvePricingUnitWeight(
            SampleVersion version,
            ExperimentForm lockedForm,
            BigDecimal referenceOutputKg
    ) {
        if (version.unitWeightKg() != null) {
            return version.unitWeightKg();
        }
        if ("kg".equals(lockedForm.finishedOutputUnit()) || referenceOutputKg == null || lockedForm.finishedOutputQuantity() == null
                || lockedForm.finishedOutputQuantity().signum() <= 0) {
            return null;
        }
        return referenceOutputKg.divide(
                lockedForm.finishedOutputQuantity(),
                6,
                RoundingMode.HALF_UP
        );
}
    @Transactional
    public synchronized NotifyFinanceResult notifyFinance(String pricingFileId, String recipientName, String remark) {
        var pricingFile = requiredPricingFile(pricingFileId);
        if (pricingFile.status() == PricingFileStatus.FINANCE_NOTIFIED) {
            var notification = currentFinanceNotification(pricingFileId);
            if (notification == null) {
                throw new BusinessException("FINANCE_NOTIFICATION_NOT_FOUND", "核价文件通知记录不存在");
            }
            return new NotifyFinanceResult(pricingFile, notification);
        }
        if (pricingFile.status() != PricingFileStatus.PRICING_APPROVED) {
            throw new BusinessException("PRICING_FILE_REVIEW_REQUIRED", "核价文件审核通过后才能通知财务");
        }
        ensureWorkflowAllows(SampleStatus.PRICING_APPROVED, SampleAction.NOTIFY_FINANCE);
        var notifiedPricingFile = pricingFile.withStatus(PricingFileStatus.FINANCE_NOTIFIED);
        pricingFiles.put(notifiedPricingFile.id(), notifiedPricingFile);
        var notification = new FinanceNotification(
                nextAvailableId("FIN", financeNotificationSequence++, financeNotifications, financeNotificationRepository),
                pricingFile.id(),
                recipientName,
                remark,
                FinanceNotificationStatus.SENT,
                now()
        );
        financeNotifications.put(notification.id(), notification);
        persistFinanceNotification(notifiedPricingFile, notification);
        return new NotifyFinanceResult(notifiedPricingFile, notification);
    }

    @Transactional
    public synchronized PricingFileRecord receivePricingFile(String pricingFileId, String receivedBy) {
        var pricingFile = requiredPricingFile(pricingFileId);
        if (pricingFile.status() != PricingFileStatus.FINANCE_NOTIFIED
                && pricingFile.status() != PricingFileStatus.FINANCE_RECEIVED) {
            throw new BusinessException("PRICING_FILE_NOT_NOTIFIED", "核价文件通知财务后才能确认接收");
        }
        if (pricingFile.status() == PricingFileStatus.FINANCE_RECEIVED) {
            return pricingFile;
        }

        var receivedAt = now();
        var receivedPricingFile = pricingFile.withStatus(PricingFileStatus.FINANCE_RECEIVED);
        persistFinanceReceipt(receivedPricingFile, receivedBy, receivedAt);
        if (auditLogService != null) {
            auditLogService.record(
                    "PRICING_FILE",
                    pricingFileId,
                    "FINANCE_RECEIVE",
                    receivedBy,
                    "receivedAt=" + receivedAt
            );
        }
        cacheAfterCommit(() -> pricingFiles.put(receivedPricingFile.id(), receivedPricingFile));
        return receivedPricingFile;
    }

    @Transactional
    public synchronized PricingFileRecord reviewPricingFile(
            String pricingFileId,
            String decision,
            String reviewerName,
            String reviewerRole,
            String comment
    ) {
        var pricingFile = requiredPricingFile(pricingFileId);
        if(!hasRole(reviewerRole,"RND_DIRECTOR")) throw new BusinessException("PRICING_FILE_REVIEW_FORBIDDEN","核价文件最终审核仅由研发总监完成");
        if (pricingFile.status() == PricingFileStatus.FINANCE_NOTIFIED
                || pricingFile.status() == PricingFileStatus.FINANCE_RECEIVED
                || pricingFile.status() == PricingFileStatus.PRICING_APPROVED
                || pricingFile.status() == PricingFileStatus.PRICING_REJECTED) {
            return pricingFile;
        }
        if (pricingFile.status() != PricingFileStatus.PENDING_PRICING_REVIEW) {
            throw new BusinessException("PRICING_FILE_REVIEW_ILLEGAL", "当前核价文件不可审核");
        }
        var normalizedDecision = decision == null ? "" : decision.trim().toUpperCase();
        var normalizedComment = comment == null ? "" : comment.trim();
        var approved = "APPROVE".equals(normalizedDecision);
        var rejected = "REJECT".equals(normalizedDecision);
        if (!approved && !rejected) {
            throw new BusinessException("PRICING_FILE_REVIEW_DECISION_INVALID", "审核结论必须是 APPROVE 或 REJECT");
        }
        if (rejected && normalizedComment.isEmpty()) {
            throw new BusinessException("PRICING_FILE_REJECTION_REASON_REQUIRED", "退回核价文件必须填写原因");
        }
        ensureWorkflowAllows(SampleStatus.PENDING_PRICING_REVIEW,
                approved ? SampleAction.APPROVE_PRICING : SampleAction.REJECT_PRICING);
        var reviewedAt = now();
        var reviewed = pricingFile.reviewed(
                approved ? PricingFileStatus.PRICING_APPROVED : PricingFileStatus.PRICING_REJECTED,
                reviewerName,
                reviewedAt,
                normalizedComment.isEmpty() ? null : normalizedComment,
                rejected ? normalizedComment : null
        );
        if(approved && pricingFileRepository != null && archiveFileRepository != null) {
            var entity=pricingFileRepository.findById(pricingFileId).orElseThrow();
            var signature=new com.lhr.rnd.model.DocumentSignature(entity.getCompiledBy(),entity.getCompiledAt()==null?null:entity.getCompiledAt().toString(),reviewerName,reviewedAt.toString());
            var oldArchive=archiveFileRepository.findFirstByBusinessTypeAndBusinessIdOrderByArchivedAtDesc("PRICING_FILE",pricingFileId).orElseThrow(()->new BusinessException("PRICING_FILE_ARCHIVE_NOT_FOUND","核价文件归档不存在"));
            var bytes=WorkbookSignatureWriter.stamp(archiveStorageService.read(oldArchive.getFilePath()),signature);
            var reservation=reservePricingArchiveAttempt(pricingFileId);var metadataReady=new boolean[]{false};
            registerPricingArchiveCompletion(reservation,metadataReady);
            reviewed=reviewed.withContentLength(bytes.length);
            persistPricingArchive(reviewed,bytes,reservation);metadataReady[0]=true;
        }
        persistPricingReview(reviewed);
        var result = reviewed;
        FinanceNotification financeNotification = null;
        if (approved) {
            result = reviewed.withStatus(PricingFileStatus.FINANCE_NOTIFIED);
            financeNotification = new FinanceNotification(
                    nextAvailableId("FIN", financeNotificationSequence++, financeNotifications, financeNotificationRepository),
                    reviewed.id(),
                    DEFAULT_FINANCE_RECIPIENT,
                    AUTO_FINANCE_REMARK,
                    FinanceNotificationStatus.SENT,
                    reviewedAt
            );
            persistFinanceNotification(result, financeNotification);
        }
        if (auditLogService != null) {
            auditLogService.record("PRICING_FILE", pricingFileId,
                    approved ? "PRICING_REVIEW_APPROVE" : "PRICING_REVIEW_REJECT", reviewerName,
                    "comment=" + normalizedComment);
            if (financeNotification != null) {
                auditLogService.record("PRICING_FILE", pricingFileId, "FINANCE_AUTO_HANDOFF", reviewerName,
                        "recipient=" + financeNotification.recipientName());
            }
        }
        var pricingFileToCache = result;
        var notificationToCache = financeNotification;
        cacheAfterCommit(() -> {
            pricingFiles.put(pricingFileToCache.id(), pricingFileToCache);
            if (notificationToCache != null) {
                financeNotifications.put(notificationToCache.id(), notificationToCache);
            }
        });
        return result;
    }

    public synchronized List<ArchiveFileView> archiveFiles(String versionId) {
        return archiveFiles(versionId, null);
    }

    public synchronized List<ArchiveFileView> archiveFiles(String versionId, String role) {
        return archiveFiles(versionId, role, null);
    }

    public synchronized List<ArchiveFileView> archiveFiles(String versionId, String role, String operatorName) {
        if (archiveFileRepository == null) {
            return List.of();
        }
        return archiveFileRepository.findByVersionIdOrderByArchivedAtDesc(versionId).stream()
                .filter(archiveFile -> !hasRole(role, "FINANCE") || isFinanceVisibleArchiveFile(archiveFile))
                .filter(archiveFile -> !hasRole(role, "RND_ENGINEER")
                        || isPricingOwnerForVersion(archiveFile.toView().versionId(), operatorName))
                .map(ArchiveFileEntity::toView)
                .toList();
    }

    public synchronized ArchiveFileDownload downloadArchiveFile(String archiveFileId) {
        return downloadArchiveFile(archiveFileId, null);
    }

    public synchronized ArchiveFileDownload downloadArchiveFile(String archiveFileId, String role) {
        return downloadArchiveFile(archiveFileId, role, null);
    }

    public synchronized ArchiveFileDownload downloadArchiveFile(String archiveFileId, String role, String operatorName) {
        if (archiveFileRepository == null) {
            throw new BusinessException("ARCHIVE_FILE_NOT_FOUND", "归档文件不存在");
        }
        var archiveFile = archiveFileRepository.findById(archiveFileId)
                .orElseThrow(() -> new BusinessException("ARCHIVE_FILE_NOT_FOUND", "归档文件不存在"));
        if (hasRole(role, "FINANCE") && !isFinanceVisibleArchiveFile(archiveFile)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_FINANCE", "财务只能下载已通过审核并通知的核价文件");
        }
        if (hasRole(role, "RND_ENGINEER")
                && !isPricingOwnerForVersion(archiveFile.toView().versionId(), operatorName)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_RND_ENGINEER", "研发人员只能下载本人负责产品的核价文件");
        }
        return new ArchiveFileDownload(
                archiveFile.getFileName(),
                archiveStorageService.read(archiveFile.getFilePath())
        );
    }

    public synchronized ArchiveFileDownload downloadPricingFile(String pricingFileId) {
        return downloadPricingFile(pricingFileId, null);
    }

    public synchronized ArchiveFileDownload downloadPricingFile(String pricingFileId, String role) {
        return downloadPricingFile(pricingFileId, role, null);
    }

    public synchronized ArchiveFileDownload downloadPricingFile(String pricingFileId, String role, String operatorName) {
        if (pricingFileRepository == null || archiveFileRepository == null) {
            throw new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在");
        }
        var pricingFile = pricingFileRepository.findById(pricingFileId)
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
        var pricingFileRecord = toPricingFileRecord(pricingFile);
        if (pricingFileRecord.status() == PricingFileStatus.DRAFT_PACKAGING) {
            throw new BusinessException("PRICING_FILE_NOT_GENERATED", "请先确认包装清单，再生成并下载核价文件");
        }
        if (hasRole(role, "FINANCE") && !isFinanceVisible(pricingFileRecord)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_FINANCE", "财务只能下载已通过审核并通知的核价文件");
        }
        if (hasRole(role, "RND_ENGINEER") && !isPricingOwner(pricingFileRecord, operatorName)) {
            throw new BusinessException("PRICING_FILE_NOT_AVAILABLE_FOR_RND_ENGINEER", "研发人员只能下载本人负责产品的核价文件");
        }
        var archiveFile = archiveFileRepository.findFirstByBusinessTypeAndBusinessIdOrderByArchivedAtDesc(
                        "PRICING_FILE",
                        pricingFileId
                )
                .orElseThrow(() -> new BusinessException("PRICING_FILE_ARCHIVE_NOT_FOUND", "核价文件归档不存在"));
        return new ArchiveFileDownload(
                archiveFile.getFileName(),
                archiveStorageService.read(archiveFile.getFilePath())
        );
    }

    @Transactional
    public synchronized ArchiveFileView archiveExperimentAttachment(
            String experimentFormId,
            String fileName,
            byte[] content,
            String category,
            String uploadedBy,
            String remark,
            String contentType
    ) {
        if (archiveFileRepository == null) {
            throw new BusinessException("ARCHIVE_FILE_REPOSITORY_NOT_READY", "归档仓库未初始化");
        }
        if (content == null || content.length == 0) {
            throw new BusinessException("ARCHIVE_FILE_EMPTY", "上传文件不能为空");
        }
        if (content.length > MAX_ATTACHMENT_SIZE_BYTES) {
            throw new BusinessException("ARCHIVE_FILE_TOO_LARGE", "上传文件不能超过10MB");
        }
        var normalizedContentType = normalizeOptional(contentType);
        if (normalizedContentType == null || !ALLOWED_ATTACHMENT_CONTENT_TYPES.contains(normalizedContentType)) {
            throw new BusinessException("ARCHIVE_FILE_TYPE_NOT_ALLOWED", "上传文件类型不允许");
        }
        var form = experimentFormArchiveContext(experimentFormId);
        var cleanFileName = cleanArchiveFileName(fileName);
        var archiveId = "ARCH-" + UUID.randomUUID().toString().replace("-", "").substring(0, 27);
        var relativePath = "%s/%s/实验附件/%s/%s".formatted(
                form.sampleNo(),
                form.versionCode(),
                archiveId,
                cleanFileName
        );
        archiveStorageService.store(relativePath, content);
        var archiveFile = new ArchiveFileEntity(
                archiveId,
                "EXPERIMENT_ATTACHMENT",
                form.id(),
                form.versionId(),
                cleanFileName,
                relativePath,
                null,
                normalizeOptional(category),
                normalizeOptional(uploadedBy),
                normalizeOptional(remark),
                normalizedContentType,
                (long) content.length,
                "ARCHIVED",
                now()
        );
        archiveFileRepository.save(archiveFile);
        return archiveFile.toView();
    }

    private LocalDateTime now() {
        return LocalDateTime.now(clock);
    }

    private SampleStatus transitionSampleStatus(SampleStatus current, SampleAction action) {
        try {
            if (workflowStatusMachine != null) {
                return workflowStatusMachine.transition(current, action);
            }
            return new SampleStatusMachine().transition(current, action);
        } catch (IllegalStateException exception) {
            throw new BusinessException("SAMPLE_STATUS_TRANSITION_ILLEGAL", exception.getMessage());
        }
    }

    private void ensureWorkflowAllows(SampleStatus current, SampleAction action) {
        transitionSampleStatus(current, action);
    }

    private void ensurePricingArchiveAllowed() {
        if (archiveFileRepository != null) {
            ensureWorkflowAllows(SampleStatus.FINANCE_NOTIFIED, SampleAction.ARCHIVE);
        }
    }

    private SampleAction customerFeedbackAction(CustomerFeedbackResult result) {
        return switch (result) {
            case PASSED -> SampleAction.CUSTOMER_FEEDBACK_PASS;
            case FAILED_RESAMPLE -> SampleAction.CUSTOMER_FEEDBACK_RESAMPLE;
            case STOPPED -> SampleAction.CUSTOMER_FEEDBACK_STOP;
        };
    }

    private CustomerResampleTask createCustomerResampleTask(String currentVersionId) {
        var currentVersion = requiredVersion(currentVersionId);
        var nextNumber = currentVersion.versionNumber() == null ? 1 : currentVersion.versionNumber() + 1;
        var nextCode = SampleVersionCode.fromNumber(nextNumber).code();
        var nextVersion = SampleVersion.builder()
                .id(nextAvailableId("VER", versions.size() + 1, versions, sampleVersionRepository))
                .projectId(currentVersion.projectId())
                .sampleNo(currentVersion.sampleNo())
                .productName(currentVersion.productName())
                .productType(currentVersion.productType())
                .specification(currentVersion.specification())
                .applicationScenario(currentVersion.applicationScenario())
                .flavorRequirement(currentVersion.flavorRequirement())
                .versionNo(nextCode)
                .versionNumber(nextNumber)
                .versionCode(nextCode)
                .ownerName(currentVersion.ownerName())
                .authorName(currentVersion.authorName())
                .createdAt(now())
                .build();
        versions.put(nextVersion.id(), nextVersion);

        var previousTask = taskByVersionId(currentVersion.id());
        var nextTaskStatus = taskStatusAfter(SampleStatus.RESAMPLING_REQUIRED, SampleAction.CREATE_NEXT_VERSION);
        var nextTask = new RndTask(
                nextAvailableId("TASK", taskSequence++, tasks, rndTaskRepository),
                nextVersion.projectId(),
                nextVersion.id(),
                nextVersion.sampleNo(),
                nextVersion.productName(),
                nextVersion.versionCode(),
                nextTaskStatus,
                previousTask == null ? null : previousTask.assigneeName(),
                previousTask == null ? null : previousTask.productOwnerName(),
                previousTask == null ? null : previousTask.dueDate(),
                now(),
                null
        );
        tasks.put(nextTask.id(), nextTask);
        return new CustomerResampleTask(nextVersion, nextTask);
    }

    private RndTask taskByVersionId(String versionId) {
        return tasks.values().stream()
                .filter(task -> task.versionId().equals(versionId))
                .findFirst()
                .orElse(null);
    }

    private SampleProject updateProjectStatusForVersion(String versionId, SampleStatus status) {
        var version = requiredVersion(versionId);
        var project = projects.get(version.projectId());
        if (project == null) {
            throw new BusinessException("SAMPLE_PROJECT_NOT_FOUND", "样品项目不存在");
        }
        var updatedProject = new SampleProject(
                project.id(),
                project.sampleNo(),
                project.productName(),
                project.productType(),
                project.customerName(),
                project.specification(),
                project.applicationScenario(),
                project.flavorRequirement(),
                status,
                project.createdAt()
        );
        projects.put(updatedProject.id(), updatedProject);
        return updatedProject;
    }

    private StoppedSampleProjectView stoppedProjectView(SampleProject project) {
        var projectVersions = versions.values().stream()
                .filter(version -> version.projectId().equals(project.id()))
                .toList();
        var lastVersionCode = projectVersions.stream()
                .max(Comparator.comparing(version -> version.versionNumber() == null ? -1 : version.versionNumber()))
                .map(SampleVersion::versionCode)
                .orElse(null);
        var stoppedFeedback = customerFeedbacks.values().stream()
                .filter(feedback -> feedback.result() == CustomerFeedbackResult.STOPPED)
                .filter(feedback -> shipmentBelongsToAnyVersion(feedback.shipmentId(), projectVersions))
                .max(Comparator.comparing(CustomerFeedback::feedbackAt));

        return new StoppedSampleProjectView(
                project.id(),
                project.sampleNo(),
                project.productName(),
                project.productType(),
                project.customerName(),
                project.specification(),
                project.status().name(),
                lastVersionCode,
                stoppedFeedback.map(CustomerFeedback::feedbackBy).orElse(null),
                stoppedFeedback.map(CustomerFeedback::comment).orElse(null),
                stoppedFeedback.map(CustomerFeedback::feedbackAt).orElse(null)
        );
    }

    private boolean shipmentBelongsToAnyVersion(String shipmentId, List<SampleVersion> projectVersions) {
        var shipment = shipments.get(shipmentId);
        if (shipment == null) {
            return false;
        }
        return projectVersions.stream().anyMatch(version -> version.id().equals(shipment.versionId()));
    }

    private RndTaskStatus taskStatusAfter(SampleStatus current, SampleAction action) {
        var nextStatus = transitionSampleStatus(current, action);
        try {
            return RndTaskStatus.valueOf(nextStatus.name());
        } catch (IllegalArgumentException exception) {
            throw new BusinessException(
                    "SAMPLE_STATUS_TRANSITION_ILLEGAL",
                    "流程配置目标状态不能用于研发任务: " + nextStatus
            );
        }
    }

    private void persistRequest(SampleRequest request) {
        if (sampleRequestRepository == null) {
            return;
        }
        sampleRequestRepository.save(new SampleRequestEntity(
                request.id(),
                request.sampleNo(),
                request.productName(),
                request.productType(),
                request.customerName(),
                request.specification(),
                request.applicationScenario(),
                request.flavorRequirement(),
                request.creatorName(),
                request.status().name(),
                request.createdAt(),
                request.referenceSampleProvided(), request.cutShape(), request.mainMaterialRequirement(), request.textureRequirement(), request.packagingRequirement(), request.storageRequirement(), request.customerTargetPrice(), request.monthlyDemand(), request.specialRequirements(), request.referenceMarketPrice(), request.additionalNotes()
        ));
    }

    private void persistApprovedWorkflow(
            SampleRequest request,
            SampleProject project,
            SampleVersion version,
            RndTask task
    ) {
        persistRequest(request);
        if (sampleProjectRepository == null || sampleVersionRepository == null || rndTaskRepository == null) {
            return;
        }
        sampleProjectRepository.save(new SampleProjectEntity(
                project.id(),
                request.id(),
                project.sampleNo(),
                project.productName(),
                project.productType(),
                project.customerName(),
                project.specification(),
                project.applicationScenario(),
                project.flavorRequirement(),
                project.status().name(),
                project.createdAt()
        ));
        sampleVersionRepository.save(new SampleVersionEntity(
                version.id(),
                version.projectId(),
                version.sampleNo(),
                version.productName(),
                version.productType(),
                version.specification(),
                version.applicationScenario(),
                version.flavorRequirement(),
                version.versionNo(),
                version.versionNumber(),
                version.versionCode(),
                version.ownerName(),
                version.authorName(),
                version.effectiveDate(),
                version.referenceOutputKg(),
                version.unitWeightKg(),
                version.createdAt()
        ));
        rndTaskRepository.save(new RndTaskEntity(
                task.id(),
                task.projectId(),
                task.versionId(),
                task.sampleNo(),
                task.productName(),
                task.versionCode(),
                task.status().name(),
                task.assigneeName(),
                task.productOwnerName(),
                task.dueDate(),
                task.createdAt(),
                task.assignedAt(),
                null
        ));
    }

    private void persistAssignedTask(RndTask task, String assigneeUserId) {
        if (rndTaskRepository == null) {
            return;
        }
        var taskEntity = rndTaskRepository.findById(task.id())
                .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
        taskEntity.assign(task.assigneeName(), task.productOwnerName(), task.dueDate(), task.assignedAt());
        taskEntity.setAssigneeUserId(assigneeUserId);
        rndTaskRepository.save(taskEntity);
    }

    private String resolveExactlyOneActiveAssignee(String assigneeName) {
        if (userAccountRepository == null) throw new BusinessException("RND_TASK_ASSIGNEE_NOT_FOUND", "研发负责人不存在或未启用");
        var assignees = userAccountRepository.findAllByNameAndStatus(assigneeName, "ACTIVE");
        if (assignees.isEmpty()) throw new BusinessException("RND_TASK_ASSIGNEE_NOT_FOUND", "研发负责人不存在或未启用");
        if (assignees.size() > 1) throw new BusinessException("RND_TASK_ASSIGNEE_AMBIGUOUS", "研发负责人姓名无法唯一解析，请由总监重新分配");
        return assignees.get(0).getId();
    }

    private void notifyTaskAssigned(RndTask task) {
        if (feishuIntegrationService == null) {
            return;
        }
        feishuIntegrationService.createTaskAssignedNotification(task);
    }

    private void persistAcceptedTask(RndTask task, LocalDateTime acceptedAt) {
        if (rndTaskRepository == null) {
            return;
        }
        var taskEntity = rndTaskRepository.findById(task.id())
                .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
        taskEntity.accept(acceptedAt);
        rndTaskRepository.save(taskEntity);
    }

    private List<ExperimentMaterial> normalizeExperimentMaterials(List<ExperimentMaterial> requestedMaterials) {
        if (requestedMaterials == null) {
            return List.of();
        }
        return requestedMaterials.stream()
                .filter(Objects::nonNull)
                .map(material -> new ExperimentMaterial(
                        material.stage(),
                        material.sequence(),
                        material.materialCode(),
                        material.materialName(),
                        material.weightKg(),
                        material.utilizationRate() == null ? BigDecimal.ONE : material.utilizationRate(),
                        material.remark(),
                        material.materialCategory() == null
                                ? categoryFromStage(material.stage())
                                : material.materialCategory(),
                        material.primaryMaterial(),
                        null,
                        material.inputUnit() == null ? "kg" : material.inputUnit(),
                        material.catalogMaterialId(), material.catalogSpecification(), material.catalogUnit(), material.refreshCatalogSnapshot(), material.id()
                ))
                .toList();
    }

    private void validateExperimentMaterials(List<ExperimentMaterial> materials) {
        var primary = materials.stream().filter(ExperimentMaterial::primaryMaterial).toList();
        if (primary.stream().anyMatch(material -> "PACKAGING".equals(material.materialCategory()))) {
            throw new BusinessException("PRIMARY_MATERIAL_INVALID", "包材不能设为主原料");
        }
        if (primary.stream().anyMatch(material -> !"RAW".equals(material.materialCategory()))) {
            throw new BusinessException("PRIMARY_MATERIAL_INVALID", "主原料必须为原料");
        }
        if (materials.stream().anyMatch(material -> !List.of("RAW", "AUXILIARY", "PACKAGING")
                .contains(material.materialCategory()))) {
            throw new BusinessException("EXPERIMENT_MATERIAL_CATEGORY_INVALID", "物料类别只允许原料、辅料或包材");
        }
    }

    private void validateSubmittableYieldBasis(ExperimentForm form) {
        validateExperimentMaterials(form.materials());
        var mode = form.yieldCalculationMode() == null
                ? YieldCalculationMode.SELECTED_PRIMARY_MATERIALS
                : form.yieldCalculationMode();
        if (mode == YieldCalculationMode.SELECTED_PRIMARY_MATERIALS
                && form.materials().stream().noneMatch(ExperimentMaterial::primaryMaterial)) {
            throw new BusinessException("PRIMARY_MATERIAL_REQUIRED", "按主料计算得率时至少需要选择一项主料");
        }
        if (mode == YieldCalculationMode.SELECTED_PRIMARY_MATERIALS
                && experimentCalculationService.yieldBasisWeight(form.materials(), mode).signum() <= 0) {
            throw new BusinessException("PRIMARY_MATERIAL_WEIGHT_REQUIRED", "提交内部测试前主料领料重量必须大于 0");
        }
        if (mode == YieldCalculationMode.TOTAL_PICKING_WEIGHT
                && experimentCalculationService.yieldBasisWeight(form.materials(), mode).signum() <= 0) {
            throw new BusinessException("YIELD_BASIS_WEIGHT_REQUIRED", "提交内部测试前得率基准重量必须大于 0");
        }
    }

    private void validateSubmittableExperiment(ExperimentForm form) {
        validateSubmittableYieldBasis(form);
        if (form.processSteps() == null || form.processSteps().stream()
                .noneMatch(step -> step.processName() != null
                        && !step.processName().isBlank()
                        && step.beforeWeightKg() != null
                        && step.beforeWeightKg().signum() > 0)) {
            throw new BusinessException("EXPERIMENT_PROCESS_REQUIRED", "提交内部测试前至少需要一道有效工序");
        }
        if (form.finishedOutputWeightKg() == null || form.finishedOutputWeightKg().signum() <= 0) {
            throw new BusinessException("FINISHED_OUTPUT_WEIGHT_REQUIRED", "提交内部测试前成品重量必须大于 0");
        }
        if (form.finishedOutputQuantity() == null || form.finishedOutputQuantity().signum() <= 0) {
            throw new BusinessException("FINISHED_OUTPUT_QUANTITY_REQUIRED", "提交内部测试前成品数量必须大于 0");
        }
    }

    private List<ExperimentMaterial> recalculateFormulaRatios(List<ExperimentMaterial> materials) {
        var formulaInputWeight = materials.stream()
                .map(ExperimentMaterial::weightKg)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return materials.stream()
                .map(material -> new ExperimentMaterial(
                        material.stage(),
                        material.sequence(),
                        material.materialCode(),
                        material.materialName(),
                        material.weightKg(),
                        material.utilizationRate(),
                        material.remark(),
                        material.materialCategory(),
                        material.primaryMaterial(),
                        formulaRatio(material.weightKg(), formulaInputWeight),
                        material.inputUnit(), material.catalogMaterialId(), material.catalogSpecification(), material.catalogUnit(), false, material.id()
                ))
                .toList();
    }

    private BigDecimal formulaRatio(BigDecimal materialWeight, BigDecimal formulaInputWeight) {
        if (materialWeight == null || formulaInputWeight == null || formulaInputWeight.signum() == 0) {
            return null;
        }
        return materialWeight.divide(formulaInputWeight, 6, RoundingMode.HALF_UP);
    }

    private List<ExperimentProcessStep> recalculateProcessLosses(List<ExperimentProcessStep> requestedSteps) {
        if (requestedSteps == null) {
            return List.of();
        }
        return requestedSteps.stream()
                .filter(Objects::nonNull)
                .map(step -> {
                    var loss = experimentCalculationService.processLoss(
                            step.beforeWeightKg(), step.afterWeightKg(), step.remainingWeightKg());
                    return new ExperimentProcessStep(
                            step.sequence(),
                            step.processName(),
                            step.beforeWeightKg(),
                            step.afterWeightKg(),
                            step.remainingWeightKg(),
                            step.remainingDisposition(),
                            loss.lossWeightKg(),
                            loss.lossRate(),
                            step.remark()
                    );
                })
                .toList();
    }

    private String categoryFromStage(String stage) {
        if (stage == null) {
            return "RAW";
        }
        var normalized = stage.trim().toUpperCase();
        if (normalized.equals("AUXILIARY") || normalized.equals("AUX") || stage.contains("辅")) {
            return "AUXILIARY";
        }
        if (normalized.equals("PACKAGING") || normalized.equals("PACKAGE") || stage.contains("包")) {
            return "PACKAGING";
        }
        return "RAW";
    }

    private void persistExperimentDraft(ExperimentForm draft) {
        if (experimentFormRepository == null || experimentMaterialRepository == null) {
            return;
        }
        experimentFormRepository.save(new ExperimentFormEntity(
                draft.id(),
                draft.taskId(),
                draft.projectId(),
                draft.versionId(),
                draft.sampleNo(),
                draft.productName(),
                draft.versionCode(),
                draft.status().name(),
                draft.operatorName(),
                draft.summary(),
                draft.finishedOutputWeightKg(),
                draft.finishedOutputQuantity(),
                draft.finishedOutputUnit(),
                draft.yieldCalculationMode().name(),
                draft.finishedYieldPercent(),
                draft.savedAt(),
                draft.submittedAt()
        ));
        experimentMaterialRepository.deleteByExperimentFormId(draft.id());
        var materialEntities = new ArrayList<ExperimentMaterialEntity>();
        for (var material : draft.materials()) {
            materialEntities.add(new ExperimentMaterialEntity(
                    material.id() == null ? UUID.randomUUID().toString().replace("-", "") : material.id(),
                    draft.id(),
                    material.stage(),
                    material.sequence(),
                    material.materialCode(),
                    material.materialName(),
                    material.weightKg(),
                    material.utilizationRate(),
                    material.remark(),
                    material.materialCategory(),
                    material.primaryMaterial(),
                    material.formulaRatio(),
                    material.inputUnit(), material.catalogMaterialId(), material.catalogSpecification(), material.catalogUnit()
            ));
        }
        experimentMaterialRepository.saveAll(materialEntities);
        if (experimentProcessRepository != null) {
            experimentProcessRepository.deleteByExperimentFormId(draft.id());
            var processEntities = new ArrayList<ExperimentProcessEntity>();
            for (var step : draft.processSteps()) {
                processEntities.add(new ExperimentProcessEntity(
                        "%s-P%04d".formatted(draft.id(), step.sequence()),
                        draft.id(),
                        step.sequence(),
                        step.processName(),
                        step.beforeWeightKg(),
                        step.afterWeightKg(),
                        step.remainingWeightKg(),
                        step.remainingDisposition(),
                        step.lossWeightKg(),
                        step.lossRate(),
                        step.remark()
                ));
            }
            experimentProcessRepository.saveAll(processEntities);
        }
    }

    private void persistSubmittedExperiment(ExperimentForm submitted, TestAssignment assignment) {
        if (experimentFormRepository == null || rndTaskRepository == null || testAssignmentRepository == null) {
            return;
        }
        var formEntity = experimentFormRepository.findById(submitted.id())
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
        formEntity.submit(submitted.submittedAt());
        experimentFormRepository.save(formEntity);

        var taskEntity = rndTaskRepository.findById(submitted.taskId())
                .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
        taskEntity.markPendingTest();
        rndTaskRepository.save(taskEntity);

        testAssignmentRepository.save(new TestAssignmentEntity(
                assignment.id(),
                assignment.experimentFormId(),
                assignment.taskId(),
                assignment.versionId(),
                assignment.processRevisionId(),
                assignment.testerName(),
                assignment.testerUserId(),
                assignment.status().name(),
                assignment.assignedAt()
        ));
    }

    private void persistPassedInternalTest(
            ExperimentForm locked,
            TestAssignment passed,
            TestRecord record,
            RndTask completedTask
    ) {
        if (experimentFormRepository == null || testAssignmentRepository == null || testRecordRepository == null) {
            return;
        }
        var formEntity = experimentFormRepository.findById(locked.id())
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
        formEntity.lock();
        experimentFormRepository.save(formEntity);

        var assignmentEntity = testAssignmentRepository.findById(passed.id())
                .orElseThrow(() -> new BusinessException("TEST_ASSIGNMENT_NOT_FOUND", "内部测试任务不存在"));
        assignmentEntity.pass();
        testAssignmentRepository.save(assignmentEntity);

        testRecordRepository.save(new TestRecordEntity(
                record.id(),
                record.testAssignmentId(),
                record.experimentFormId(),
                record.testerName(),
                record.result().name(),
                record.comment(),
                record.testedAt()
        ));

        if (completedTask != null && rndTaskRepository != null) {
            var taskEntity = rndTaskRepository.findById(completedTask.id())
                    .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
            taskEntity.complete();
            rndTaskRepository.save(taskEntity);
        }
    }

    private void persistFailedInternalTest(
            ExperimentForm locked,
            TestAssignment failed,
            TestRecord record,
            SampleVersion nextVersion,
            RndTask previousTask,
            RndTask nextTask
    ) {
        if (experimentFormRepository == null || testAssignmentRepository == null || testRecordRepository == null
                || sampleVersionRepository == null || rndTaskRepository == null) {
            return;
        }
        var formEntity = experimentFormRepository.findById(locked.id())
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
        formEntity.lock();
        experimentFormRepository.save(formEntity);
        var assignmentEntity = testAssignmentRepository.findById(failed.id())
                .orElseThrow(() -> new BusinessException("TEST_ASSIGNMENT_NOT_FOUND", "内部测试任务不存在"));
        assignmentEntity.failForResample();
        testAssignmentRepository.save(assignmentEntity);

        testRecordRepository.save(new TestRecordEntity(
                record.id(),
                record.testAssignmentId(),
                record.experimentFormId(),
                record.testerName(),
                record.result().name(),
                record.comment(),
                record.testedAt()
        ));

        sampleVersionRepository.save(new SampleVersionEntity(
                nextVersion.id(),
                nextVersion.projectId(),
                nextVersion.sampleNo(),
                nextVersion.productName(),
                nextVersion.productType(),
                nextVersion.specification(),
                nextVersion.applicationScenario(),
                nextVersion.flavorRequirement(),
                nextVersion.versionNo(),
                nextVersion.versionNumber(),
                nextVersion.versionCode(),
                nextVersion.ownerName(),
                nextVersion.authorName(),
                nextVersion.effectiveDate(),
                nextVersion.referenceOutputKg(),
                nextVersion.unitWeightKg(),
                nextVersion.createdAt()
        ));

        String inheritedAssigneeUserId = null;
        if (previousTask != null) {
            var previousTaskEntity = rndTaskRepository.findById(previousTask.id())
                    .orElseThrow(() -> new BusinessException("RND_TASK_NOT_FOUND", "研发任务不存在"));
            inheritedAssigneeUserId = previousTaskEntity.getAssigneeUserId();
            previousTaskEntity.complete();
            rndTaskRepository.save(previousTaskEntity);
        }

        var nextEntity = new RndTaskEntity(
                nextTask.id(),
                nextTask.projectId(),
                nextTask.versionId(),
                nextTask.sampleNo(),
                nextTask.productName(),
                nextTask.versionCode(),
                nextTask.status().name(),
                nextTask.assigneeName(),
                nextTask.productOwnerName(),
                nextTask.dueDate(),
                nextTask.createdAt(),
                nextTask.assignedAt(),
                null
        );
        nextEntity.setAssigneeUserId(inheritedAssigneeUserId);
        rndTaskRepository.save(nextEntity);
    }

    private void persistShipment(ShipmentRecord shipment) {
        if (shipmentRecordRepository == null) {
            return;
        }
        shipmentRecordRepository.save(new ShipmentRecordEntity(
                shipment.id(),
                shipment.versionId(),
                shipment.sampleNo(),
                shipment.productName(),
                shipment.versionCode(),
                shipment.quantity(),
                shipment.receiverName(),
                shipment.trackingNo(),
                shipment.remark(),
                shipment.status().name(),
                shipment.shippedAt()
        ));
    }

    private void persistCustomerFeedback(ShipmentRecord updatedShipment, CustomerFeedback feedback) {
        if (shipmentRecordRepository == null || customerFeedbackRepository == null) {
            return;
        }
        var shipmentEntity = shipmentRecordRepository.findById(updatedShipment.id())
                .orElseThrow(() -> new BusinessException("SHIPMENT_NOT_FOUND", "寄样记录不存在"));
        shipmentEntity.updateStatus(updatedShipment.status().name());
        shipmentRecordRepository.save(shipmentEntity);

        customerFeedbackRepository.save(new CustomerFeedbackEntity(
                feedback.id(),
                feedback.shipmentId(),
                feedback.feedbackBy(),
                feedback.result().name(),
                feedback.comment(),
                feedback.feedbackAt()
        ));
    }

    private void persistCustomerResampleTask(SampleVersion nextVersion, RndTask previousTask, RndTask nextTask) {
        if (sampleVersionRepository == null || rndTaskRepository == null) {
            return;
        }
        sampleVersionRepository.save(new SampleVersionEntity(
                nextVersion.id(),
                nextVersion.projectId(),
                nextVersion.sampleNo(),
                nextVersion.productName(),
                nextVersion.productType(),
                nextVersion.specification(),
                nextVersion.applicationScenario(),
                nextVersion.flavorRequirement(),
                nextVersion.versionNo(),
                nextVersion.versionNumber(),
                nextVersion.versionCode(),
                nextVersion.ownerName(),
                nextVersion.authorName(),
                nextVersion.effectiveDate(),
                nextVersion.referenceOutputKg(),
                nextVersion.unitWeightKg(),
                nextVersion.createdAt()
        ));

        var nextEntity = new RndTaskEntity(
                nextTask.id(),
                nextTask.projectId(),
                nextTask.versionId(),
                nextTask.sampleNo(),
                nextTask.productName(),
                nextTask.versionCode(),
                nextTask.status().name(),
                nextTask.assigneeName(),
                nextTask.productOwnerName(),
                nextTask.dueDate(),
                nextTask.createdAt(),
                nextTask.assignedAt(),
                null
        );
        if (previousTask != null) {
            rndTaskRepository.findById(previousTask.id()).ifPresent(previous -> nextEntity.setAssigneeUserId(previous.getAssigneeUserId()));
        }
        rndTaskRepository.save(nextEntity);
    }

    private void persistSampleProjectStatus(SampleProject project) {
        if (sampleProjectRepository == null) {
            return;
        }
        var projectEntity = sampleProjectRepository.findById(project.id())
                .orElseThrow(() -> new BusinessException("SAMPLE_PROJECT_NOT_FOUND", "样品项目不存在"));
        projectEntity.updateStatus(project.status().name());
        sampleProjectRepository.save(projectEntity);
    }

    private void persistPricingDraft(PricingFileRecord pricingFile) {
        if (pricingFileRepository == null) {
            return;
        }
        pricingFileRepository.save(new PricingFileEntity(
                pricingFile.id(),
                pricingFile.versionId(),
                pricingFile.sampleNo(),
                pricingFile.productName(),
                pricingFile.versionCode(),
                pricingFile.pricingVersion(),
                pricingFile.fileName(),
                pricingFile.status().name(),
                pricingFile.contentLength(),
                pricingFile.generatedAt(),
                null,
                null,
                pricingFile.reviewedBy(),
                pricingFile.reviewedAt(),
                pricingFile.reviewComment(),
                pricingFile.rejectionReason()
        ));
    }

    private void persistGeneratedPricingFile(
            PricingFileRecord pricingFile,
            byte[] content,
            PricingArchiveCleanupLedgerService.Reservation archiveReservation
    ) {
        if (pricingFileRepository == null) {
            return;
        }
        var entity = pricingFileRepository.findById(pricingFile.id())
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
        entity.markGenerated(pricingFile.fileName(), pricingFile.contentLength());
        entity.setProcessRevisionId(pricingFile.processRevisionId());
        pricingFileRepository.save(entity);
        persistPricingArchive(pricingFile, content, archiveReservation);
    }

    private void persistPricingPackagingItems(String pricingFileId, List<PricingPackagingItem> items) {
        if (pricingPackagingItemRepository == null) {
            return;
        }
        pricingPackagingItemRepository.deleteByPricingFileId(pricingFileId);
        pricingPackagingItemRepository.saveAll(items.stream()
                .map(item -> {
                    var entity = new PricingPackagingItemEntity(
                        item.id(), item.pricingFileId(), item.sequence(), item.source().name(),
                        item.materialCode(), item.materialName(), item.quantity(), item.packageSpec(),
                        item.conversionRule(), item.remark(), item.confirmationStatus().name(),
                        item.modificationReason());
                    entity.setQuantityUnit(item.quantityUnit());
                    return entity;
                })
                .toList());
    }

    private void persistPricingArchive(
            PricingFileRecord pricingFile,
            byte[] content,
            PricingArchiveCleanupLedgerService.Reservation archiveReservation
    ) {
        if (archiveFileRepository == null) {
            return;
        }
        if (archiveReservation == null) {
            throw new IllegalStateException("pricing archive cleanup ledger is required");
        }
        pricingArchiveCleanupLedger.renew(archiveReservation);
        var relativePath = archiveReservation.storageKey();
        archiveStorageService.store(relativePath, content);
        if (!pricingArchiveCleanupLedger.lockForCommit(archiveReservation)) {
            archiveStorageService.delete(relativePath);
            throw new BusinessException("PRICING_ARCHIVE_RESERVATION_LOST", "核价归档生成租约已失效，请重试");
        }
        archiveFileRepository.save(new ArchiveFileEntity(
                "ARCH-" + pricingFile.id(),
                "PRICING_FILE",
                pricingFile.id(),
                pricingFile.versionId(),
                pricingFile.fileName(),
                relativePath,
                null,
                "PRICING",
                null,
                pricingFile.processRevisionId() == null
                        ? "source=LEGACY"
                        : "processRevisionId=" + pricingFile.processRevisionId(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                (long) content.length,
                "ARCHIVED",
                pricingFile.generatedAt()
        ));
    }

    private void persistFinanceNotification(PricingFileRecord notifiedPricingFile, FinanceNotification notification) {
        if (pricingFileRepository == null || financeNotificationRepository == null) {
            return;
        }
        var pricingFileEntity = pricingFileRepository.findById(notifiedPricingFile.id())
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
        pricingFileEntity.markFinanceNotified();
        pricingFileRepository.save(pricingFileEntity);

        financeNotificationRepository.save(new FinanceNotificationEntity(
                notification.id(),
                notification.pricingFileId(),
                notification.recipientName(),
                notification.remark(),
                notification.status().name(),
                notification.notifiedAt()
        ));
    }

    private void persistPricingReview(PricingFileRecord reviewedPricingFile) {
        if (pricingFileRepository == null) {
            return;
        }
        var entity = pricingFileRepository.findById(reviewedPricingFile.id())
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
        entity.markReviewed(
                reviewedPricingFile.status().name(),
                reviewedPricingFile.reviewedBy(),
                reviewedPricingFile.reviewedAt(),
                reviewedPricingFile.reviewComment(),
                reviewedPricingFile.rejectionReason()
        );
        entity.updateContentLength(reviewedPricingFile.contentLength());
        pricingFileRepository.save(entity);
    }

    private void persistFinanceReceipt(
            PricingFileRecord receivedPricingFile,
            String receivedBy,
            LocalDateTime receivedAt
    ) {
        if (pricingFileRepository == null) {
            return;
        }
        var pricingFileEntity = pricingFileRepository.findById(receivedPricingFile.id())
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
        pricingFileEntity.markFinanceReceived(receivedBy, receivedAt);
        pricingFileRepository.save(pricingFileEntity);
    }

    private SampleVersion requiredVersion(String versionId) {
        var version = versions.get(versionId);
        if (version != null) return version;
        if (sampleVersionRepository == null) throw new BusinessException("SAMPLE_VERSION_NOT_FOUND", "样品版本不存在");
        return sampleVersionRepository.findById(versionId).map(entity -> SampleVersion.builder()
                        .id(entity.getId()).projectId(entity.getProjectId()).sampleNo(entity.getSampleNo())
                        .productName(entity.getProductName()).productType(entity.getProductType()).specification(entity.getSpecification())
                        .applicationScenario(entity.getApplicationScenario()).flavorRequirement(entity.getFlavorRequirement())
                        .versionNo(entity.getVersionNo()).versionNumber(entity.getVersionNumber()).versionCode(entity.getVersionCode())
                        .ownerName(entity.getOwnerName()).authorName(entity.getAuthorName()).effectiveDate(entity.getEffectiveDate())
                        .referenceOutputKg(entity.getReferenceOutputKg()).unitWeightKg(entity.getUnitWeightKg())
                        .createdAt(entity.getCreatedAt()).build())
                .map(hydrated -> { versions.put(hydrated.id(), hydrated); return hydrated; })
                .orElseThrow(() -> new BusinessException("SAMPLE_VERSION_NOT_FOUND", "样品版本不存在"));
    }

    private ExperimentForm lockedExperimentForm(String versionId) {
        var cached = experimentForms.values().stream()
                .filter(form -> form.versionId().equals(versionId))
                .filter(form -> form.status() == ExperimentFormStatus.LOCKED)
                .findFirst()
                .orElse(null);
        if (cached != null) {
            return cached;
        }
        if (experimentFormRepository != null) {
            var persisted = experimentFormRepository
                    .findFirstByVersionIdAndStatusOrderBySavedAtDesc(versionId, ExperimentFormStatus.LOCKED.name())
                    .map(this::hydrateExperimentForm)
                    .orElse(null);
            if (persisted != null) {
                experimentForms.put(persisted.id(), persisted);
                return persisted;
            }
        }
        throw new BusinessException("SAMPLE_VERSION_NOT_READY_FOR_PRICING", "实验单锁定后才能生成核价文件");
    }

    private ExperimentFormArchiveContext experimentFormArchiveContext(String experimentFormId) {
        var form = experimentForms.get(experimentFormId);
        if (form != null) {
            return new ExperimentFormArchiveContext(
                    form.id(),
                    form.versionId(),
                    form.sampleNo(),
                    form.versionCode()
            );
        }
        if (experimentFormRepository == null) {
            throw new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在");
        }
        var entity = experimentFormRepository.findById(experimentFormId)
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
        return new ExperimentFormArchiveContext(
                entity.getId(),
                entity.getVersionId(),
                entity.getSampleNo(),
                entity.getVersionCode()
        );
    }

    private String cleanArchiveFileName(String fileName) {
        if (fileName == null || fileName.isBlank()) {
            throw new BusinessException("ARCHIVE_FILE_NAME_REQUIRED", "归档文件名不能为空");
        }
        var cleanFileName = fileName.replace("\\", "/")
                .replaceAll(".*/", "")
                .trim();
        if (cleanFileName.isBlank()) {
            throw new BusinessException("ARCHIVE_FILE_NAME_REQUIRED", "归档文件名不能为空");
        }
        return cleanFileName;
    }

    private String normalizeOptional(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalizeProductOwnerName(String productOwnerName, String assigneeName) {
        var normalized = normalizeOptional(productOwnerName);
        return normalized == null ? assigneeName : normalized;
    }

    private String normalizeFinishedOutputUnit(String finishedOutputUnit) {
        var normalized = normalizeOptional(finishedOutputUnit);
        return normalized == null ? "袋" : normalized;
    }

    private void ensureReadyForShipment(String versionId) {
        try {
            lockedExperimentForm(versionId);
        } catch (BusinessException exception) {
            throw new BusinessException("SAMPLE_VERSION_NOT_READY_FOR_SHIPMENT", "实验单锁定后才能寄样");
        }
    }

    private long nextPricingVersionNumber(String versionId) {
        return allPricingFiles().stream().filter(file -> file.versionId().equals(versionId)).count() + 1;
    }

    private boolean canGenerateNextPricingVersion(String versionId) {
        var latest = allPricingFiles().stream()
                .filter(file -> file.versionId().equals(versionId))
                .max(Comparator.comparing(PricingFileRecord::generatedAt))
                .orElse(null);
        if (latest == null || latest.status() == PricingFileStatus.PRICING_REJECTED) return true;
        // A submitted/approved pricing file closes only its own formal process revision.
        // A newly published SOP needs a separate pricing version, never a rewrite of the old file.
        if (latest.status() == PricingFileStatus.DRAFT_PACKAGING) return false;
        var formal = latestFormalPricingRevision(lockedExperimentForm(versionId));
        return formal != null && !Objects.equals(formal.id(), latest.processRevisionId());
    }

    private List<PricingFileRecord> allPricingFiles() {
        if (pricingFileRepository != null) {
            pricingFileRepository.findAll().stream()
                    .map(this::toPricingFileRecord)
                    .forEach(file -> pricingFiles.put(file.id(), file));
        }
        return new ArrayList<>(pricingFiles.values());
    }

    private boolean isFinanceVisible(PricingFileRecord pricingFile) {
        return pricingFile.status() == PricingFileStatus.FINANCE_NOTIFIED
                || pricingFile.status() == PricingFileStatus.FINANCE_RECEIVED;
    }

    private boolean isFinanceVisibleArchiveFile(ArchiveFileEntity archiveFile) {
        if (!"PRICING_FILE".equals(archiveFile.getBusinessType())) {
            return true;
        }
        var pricingFile = pricingFiles.get(archiveFile.getBusinessId());
        if (pricingFile == null && pricingFileRepository != null) {
            pricingFile = pricingFileRepository.findById(archiveFile.getBusinessId())
                    .map(this::toPricingFileRecord)
                    .orElse(null);
        }
        return pricingFile != null && isFinanceVisible(pricingFile);
    }

    private boolean isPricingOwner(PricingFileRecord pricingFile, String operatorName) {
        return isPricingOwnerForVersion(pricingFile.versionId(), operatorName);
    }

    private boolean isPricingOwnerForVersion(String versionId, String operatorName) {
        if (operatorName == null || operatorName.isBlank()) {
            return false;
        }
        return pricingTask(versionId)
                .map(RndTask::productOwnerName)
                .filter(operatorName::equals)
                .isPresent();
    }

    private void ensurePricingReviewer(PricingFileRecord pricingFile, String reviewerName, String reviewerRole) {
        if (hasRole(reviewerRole, "RND_DIRECTOR")) {
            return;
        }
        var task = pricingTask(pricingFile.versionId()).orElse(null);
        if (!hasRole(reviewerRole, "RND_ENGINEER", "RND") || task == null
                || !reviewerName.equals(task.productOwnerName())) {
            throw new BusinessException("PRICING_FILE_REVIEW_FORBIDDEN", "仅研发总监或产品负责人可审核核价文件");
        }
    }

    private Optional<RndTask> pricingTask(String versionId) {
        return tasks.values().stream()
                .filter(candidate -> candidate.versionId().equals(versionId))
                .findFirst()
                .or(() -> rndTaskRepository == null ? Optional.empty() : rndTaskRepository.findAll().stream()
                        .filter(candidate -> candidate.getVersionId().equals(versionId))
                        .findFirst()
                        .map(this::hydrateRndTask));
    }

    private PricingFileRecord toPricingFileRecord(com.lhr.rnd.persistence.entity.PricingFileEntity entity) {
        return new PricingFileRecord(
                entity.getId(), entity.getVersionId(), entity.getSampleNo(), entity.getProductName(),
                entity.getVersionCode(), entity.getPricingVersion(), entity.getFileName(),
                PricingFileStatus.valueOf(entity.getStatus()), entity.getContentLength(), entity.getGeneratedAt(),
                entity.getReviewedBy(), entity.getReviewedAt(), entity.getReviewComment(), entity.getRejectionReason(),
                entity.getProcessRevisionId()
        );
    }

    private PricingFileRecord lockedPricingFile(String pricingFileId) {
        if (pricingFileRepository == null) {
            return requiredPricingFile(pricingFileId);
        }
        return pricingFileRepository.findByIdForUpdate(pricingFileId)
                .map(this::toPricingFileRecord)
                .orElseThrow(() -> new BusinessException("PRICING_FILE_NOT_FOUND", "核价文件不存在"));
    }

    private PricingArchiveCleanupLedgerService.Reservation reservePricingArchiveAttempt(String pricingFileId) {
        if (pricingArchiveCleanupLedger == null) {
            return null;
        }
        pricingArchiveCleanupLedger.reconcileStale();
        return pricingArchiveCleanupLedger.register(pricingFileId);
    }

    private void registerPricingArchiveCompletion(
            PricingArchiveCleanupLedgerService.Reservation reservation,
            boolean[] archiveMetadataReady
    ) {
        if (reservation == null) {
            return;
        }
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            pricingArchiveCleanupLedger.orphanAndDelete(reservation);
            throw new IllegalStateException("pricing archive attempt requires transaction synchronization");
        }
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status == STATUS_COMMITTED && archiveMetadataReady[0]) {
                    pricingArchiveCleanupLedger.confirm(reservation);
                } else {
                    pricingArchiveCleanupLedger.orphanAndDelete(reservation);
                }
            }
        });
    }

    private ProcessRevision latestFormalPricingRevision(ExperimentForm lockedForm) {
        if (processRevisionService == null) {
            return null;
        }
        var revision = processRevisionService.latestOrNull(lockedForm.id());
        if (revision != null && !lockedForm.id().equals(revision.experimentFormId())) {
            throw new BusinessException("PROCESS_REVISION_PRICING_FORM_MISMATCH", "正式工艺版本不属于当前样品实验单");
        }
        return revision;
    }

    private PricingProcessSource pricingProcessSource(PricingFileRecord pricingFile, SampleVersion version) {
        if (pricingFile.processRevisionId() == null) {
            return new PricingProcessSource("LEGACY", null, null, null);
        }
        if (processRevisionService == null) {
            return new PricingProcessSource("FORMAL_PROCESS_REVISION", pricingFile.processRevisionId(), null, null);
        }
        var form = lockedExperimentForm(version.id());
        var revision = processRevisionService.find(form.id(), pricingFile.processRevisionId());
        return new PricingProcessSource("FORMAL_PROCESS_REVISION", revision.id(), revision.revisionNo(),
                new com.lhr.rnd.domain.ProcessPlanCalculationService().calculateBatch(revision.snapshot()));
    }

    private PricingPackagingItem toPricingPackagingItem(PricingPackagingItemEntity entity) {
        return new PricingPackagingItem(
                entity.getId(), entity.getPricingFileId(), entity.getSequence(),
                PricingPackagingSource.valueOf(entity.getSource()), entity.getMaterialCode(),
                entity.getMaterialName(), entity.getQuantity(), entity.getPackageSpec(),
                entity.getConversionRule(), entity.getRemark(),
                PricingPackagingStatus.valueOf(entity.getConfirmationStatus()), entity.getModificationReason(), entity.getQuantityUnit()
        );
    }

    private PackagingTemplateItem toPackagingTemplateItem(PackagingTemplateItemEntity entity) {
        return new PackagingTemplateItem(
                entity.getTemplateCode(), entity.getSequence(), entity.getMaterialCode(),
                entity.getMaterialName(), entity.getConversionType(), entity.getUnitsPerParent(),
                entity.getPackageSpec(), entity.getRemark(), entity.getQuantityUnit()
        );
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private FinanceNotification toFinanceNotification(FinanceNotificationEntity entity) {
        return new FinanceNotification(
                entity.getId(),
                entity.getPricingFileId(),
                entity.getRecipientName(),
                entity.getRemark(),
                FinanceNotificationStatus.valueOf(entity.getStatus()),
                entity.getNotifiedAt()
        );
    }

    private TestAssignment pendingTestAssignment(String testAssignmentId, String testerName) {
        var assignment = pendingTestAssignment(testAssignmentId);
        if (!testerName.equals(assignment.testerName())) {
            throw new BusinessException("TEST_ASSIGNMENT_TESTER_MISMATCH", "只能由被配置的测试人员确认");
        }
        return assignment;
    }

    private TestAssignment pendingTestAssignment(String testAssignmentId, SessionPrincipal principal) {
        if (principal == null || principal.userId() == null || principal.userId().isBlank()
                || !("TESTER".equals(principal.role()) || "QA_TESTER".equals(principal.role()))) {
            throw new BusinessException("TEST_ASSIGNMENT_TESTER_MISMATCH", "只能由被配置的测试人员确认");
        }
        var assignment = pendingTestAssignment(testAssignmentId);
        var testerUserId = assignment.testerUserId();
        if (testerUserId == null || testerUserId.isBlank()) testerUserId = requireTesterUserId(assignment.testerName());
        if (!principal.userId().equals(testerUserId)) {
            throw new BusinessException("TEST_ASSIGNMENT_TESTER_MISMATCH", "只能由被配置的测试人员确认");
        }
        if (assignment.processRevisionId() == null || assignment.processRevisionId().isBlank()) {
            throw new BusinessException("PROCESS_FORMAL_REVISION_REQUIRED", "该测试任务未绑定正式工艺版本，请研发重新送测");
        }
        return assignment;
    }

    private TestAssignment pendingTestAssignment(String testAssignmentId) {
        var assignment = testAssignmentRepository == null ? testAssignments.get(testAssignmentId)
                : testAssignmentRepository.findActiveByIdForUpdate(testAssignmentId).map(this::hydrateTestAssignment).orElse(null);
        if (assignment == null) throw new BusinessException("TEST_ASSIGNMENT_NOT_FOUND", "内部测试任务不存在");
        testAssignments.put(assignment.id(), assignment);
        if (assignment.status() != TestAssignmentStatus.PENDING_TEST) {
            throw new BusinessException("TEST_ASSIGNMENT_STATUS_ILLEGAL", "当前测试任务状态不可确认");
        }
        return assignment;
    }

    private void lockExperimentFormForSubmission(String experimentFormId) {
        if (experimentFormRepository == null) return;
        var entity = experimentFormRepository.findByIdForUpdate(experimentFormId)
                .orElseThrow(() -> new BusinessException("EXPERIMENT_FORM_NOT_FOUND", "实验单不存在"));
        if (!ExperimentFormStatus.DRAFT.name().equals(entity.getStatus())) {
            throw new BusinessException("EXPERIMENT_FORM_STATUS_ILLEGAL", "只有草稿实验单可以提交测试");
        }
    }

    private String requireTesterUserId(String testerName) {
        return resolveTester(testerName).userId();
    }

    private TesterIdentity resolveTester(String requestedName) {
        if (userAccountRepository == null) return new TesterIdentity(null, requestedName);
        var eligible = userAccountRepository.findAll().stream()
                .filter(account -> "ACTIVE".equals(account.getStatus()))
                .filter(account -> "TESTER".equals(account.getRole()) || "QA_TESTER".equals(account.getRole()))
                .toList();
        var matches = "AUTO_ASSIGN".equals(requestedName)
                ? eligible
                : eligible.stream().filter(account -> account.getName().equals(requestedName)).toList();
        if (matches.size() != 1) {
            throw new BusinessException("TESTER_ACCOUNT_NOT_UNIQUE", "内部测试人员账号不存在或无法唯一确定，请先配置或选择唯一测试账号");
        }
        return new TesterIdentity(matches.get(0).getId(), matches.get(0).getName());
    }

    private TestAssignment hydrateTestAssignment(TestAssignmentEntity entity) {
        return new TestAssignment(
                entity.getId(),
                entity.getExperimentFormId(),
                entity.getTaskId(),
                entity.getVersionId(),
                entity.getProcessRevisionId(),
                entity.getTesterName(),
                entity.getTesterUserId(),
                TestAssignmentStatus.valueOf(entity.getStatus()),
                entity.getAssignedAt()
        );
    }

    private TestRecord testRecord(TestAssignment assignment, String testerName, TestAssignmentStatus result, String comment) {
        var record = new TestRecord(
                nextTestRecordId(),
                assignment.id(),
                assignment.experimentFormId(),
                testerName,
                result,
                comment,
                now()
        );
        return record;
    }

    public record CreateSampleRequestCommand(
            String productName,
            String productType,
            String customerName,
            String specification,
            String applicationScenario,
            String flavorRequirement,
            String creatorName,
        Boolean referenceSampleProvided,
        String cutShape,
        String mainMaterialRequirement,
        String textureRequirement,
        String packagingRequirement,
        String storageRequirement,
        String customerTargetPrice,
        String monthlyDemand,
        String specialRequirements,
        String referenceMarketPrice,
        String additionalNotes
    ) {
        public CreateSampleRequestCommand {
            productName=com.lhr.rnd.domain.SampleRequirementValidation.text(productName,"产品名称",true,200);
            customerName=com.lhr.rnd.domain.SampleRequirementValidation.text(customerName,"客户名称",true,200);
            specification=com.lhr.rnd.domain.SampleRequirementValidation.text(specification,"产品规格",true,100);
            productType=com.lhr.rnd.domain.SampleRequirementValidation.text(productType,"产品类型",true,100);
            creatorName=com.lhr.rnd.domain.SampleRequirementValidation.text(creatorName,"申请人",true,100);
            applicationScenario=com.lhr.rnd.domain.SampleRequirementValidation.text(applicationScenario,"应用场景",true,500);
            flavorRequirement=com.lhr.rnd.domain.SampleRequirementValidation.text(flavorRequirement,"味型",true,500);
            if(referenceSampleProvided==null)throw new BusinessException("SAMPLE_REQUIREMENT_REQUIRED","请填写是否提供标样");
            cutShape=com.lhr.rnd.domain.SampleRequirementValidation.text(cutShape,"块型",true);
            mainMaterialRequirement=com.lhr.rnd.domain.SampleRequirementValidation.text(mainMaterialRequirement,"主要原料要求",true);
            textureRequirement=com.lhr.rnd.domain.SampleRequirementValidation.text(textureRequirement,"口感",true);
            packagingRequirement=com.lhr.rnd.domain.SampleRequirementValidation.text(packagingRequirement,"包装要求",true);
            storageRequirement=com.lhr.rnd.domain.SampleRequirementValidation.text(storageRequirement,"储存方式",true);
            customerTargetPrice=com.lhr.rnd.domain.SampleRequirementValidation.text(customerTargetPrice,"客户目标价格",true);
            monthlyDemand=com.lhr.rnd.domain.SampleRequirementValidation.text(monthlyDemand,"需求量（每月）",true);
            specialRequirements=com.lhr.rnd.domain.SampleRequirementValidation.text(specialRequirements,"其他特殊要求",true);
            referenceMarketPrice=com.lhr.rnd.domain.SampleRequirementValidation.text(referenceMarketPrice,"行情/参考价格",false);
            additionalNotes=com.lhr.rnd.domain.SampleRequirementValidation.text(additionalNotes,"其他补充说明",false);
        }
    }

    public record SaveExperimentDraftCommand(
            String taskId,
            String operatorName,
            String summary,
            List<ExperimentMaterial> materials,
            List<ExperimentProcessStep> processSteps,
            BigDecimal finishedOutputWeightKg,
            BigDecimal finishedOutputQuantity,
            String finishedOutputUnit,
            BigDecimal finishedYieldPercent,
            YieldCalculationMode yieldCalculationMode
    ) {
        public SaveExperimentDraftCommand(
                String taskId,
                String operatorName,
                String summary,
                List<ExperimentMaterial> materials,
                List<ExperimentProcessStep> processSteps,
                BigDecimal finishedOutputWeightKg,
                BigDecimal finishedOutputQuantity,
                String finishedOutputUnit,
                BigDecimal finishedYieldPercent
        ) {
            this(taskId, operatorName, summary, materials, processSteps, finishedOutputWeightKg,
                    finishedOutputQuantity, finishedOutputUnit, finishedYieldPercent,
                    YieldCalculationMode.SELECTED_PRIMARY_MATERIALS);
        }

        public SaveExperimentDraftCommand(
                String taskId,
                String operatorName,
                String summary,
                List<ExperimentMaterial> materials,
                List<ExperimentProcessStep> processSteps
        ) {
            this(taskId, operatorName, summary, materials, processSteps, null, null, null, null,
                    YieldCalculationMode.SELECTED_PRIMARY_MATERIALS);
        }
    }

    public record CreateShipmentCommand(
            String versionId,
            Integer quantity,
            String receiverName,
            String trackingNo,
            String remark
    ) {
    }

    public record SubmitCustomerFeedbackCommand(
            String shipmentId,
            String feedbackBy,
            CustomerFeedbackResult result,
            String comment
    ) {
    }

    public record ArchiveFileDownload(
            String fileName,
            byte[] content
    ) {
    }

    private record ExperimentFormArchiveContext(
            String id,
            String versionId,
            String sampleNo,
            String versionCode
    ) {
    }

    private record TesterIdentity(String userId, String name) {
    }

    private record CustomerResampleTask(
            SampleVersion nextVersion,
            RndTask nextTask
    ) {
    }
}
