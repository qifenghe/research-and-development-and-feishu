-- Apply the same widening when upgrading a database that already passed V16.
alter table role_permission alter column id type varchar(128);
