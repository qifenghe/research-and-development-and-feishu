-- Allow existing long permission identifiers before V16 on a fresh PostgreSQL database.
alter table role_permission alter column id type varchar(128);
